declare module 'pdf-parse/lib/pdf-parse.js' {
  interface PDFParseOptions {
    pagerender?: (pageData: any) => string | Promise<string>;
    max?: number;
    normalizeWhitespace?: boolean;
    disableCombineTextItems?: boolean;
  }

  interface PDFParseResult {
    text: string;
    numpages: number;
    numrender: number;
    info: any;
    metadata: any;
    version: string;
  }

  function pdfParse(data: Buffer, options?: PDFParseOptions): Promise<PDFParseResult>;
  export default pdfParse;
}
