'use client';

import type React from 'react';

import { useState } from 'react';
import { Upload, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import mammoth from 'mammoth';

interface FileUploadProps {
  onFileProcessed: (content: string, fileName: string) => void;
  onError: (error: string) => void;
}

export function FileUpload({ onFileProcessed, onError }: FileUploadProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setError(null);

    try {
      const fileExtension = file.name.split('.').pop()?.toLowerCase();
      let extractedText = '';

      // Process based on file type
      if (fileExtension === 'docx') {
        extractedText = await extractTextFromDocx(file);
      } else if (fileExtension === 'pdf') {
        extractedText = await extractTextFromPdf(file);
      } else if (fileExtension === 'txt') {
        extractedText = await extractTextFromTxt(file);
      } else {
        throw new Error(`Unsupported file type: .${fileExtension}`);
      }

      if (extractedText.trim().length === 0) {
        throw new Error('No text could be extracted from the file.');
      }

      onFileProcessed(extractedText, file.name);
      toast({
        title: 'File processed successfully',
        description: `Extracted ${extractedText.length} characters from ${file.name}`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to process file';
      setError(errorMessage);
      onError(errorMessage);
      toast({
        title: 'Error processing file',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Extract text from DOCX using mammoth
  const extractTextFromDocx = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  };

  // Extract text from PDF using pdf-parse
  const extractTextFromPdf = async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/parse-pdf', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to extract text from PDF');
      }

      const data = await response.json();
      if (!data.text) {
        throw new Error('No text could be extracted from the PDF');
      }

      return data.text;
    } catch (error) {
      console.error('PDF parsing error:', error);
      throw error;
    }
  };

  // Extract text from TXT file
  const extractTextFromTxt = async (file: File): Promise<string> => {
    return await file.text();
  };

  return (
    <div className="w-full">
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex w-full items-center justify-center">
        <label
          htmlFor="file-upload"
          className="flex h-32 w-full cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-muted/50 transition-colors hover:bg-muted"
        >
          <div className="flex flex-col items-center justify-center pb-6 pt-5">
            {isProcessing ? (
              <div className="flex flex-col items-center">
                <div className="mb-2 h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                <p className="text-sm text-muted-foreground">Processing file...</p>
              </div>
            ) : (
              <>
                <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                <p className="mb-2 text-sm text-muted-foreground">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-muted-foreground">PDF, DOCX, or TXT (Max 10MB)</p>
              </>
            )}
          </div>
          <input
            id="file-upload"
            type="file"
            className="hidden"
            accept=".pdf,.docx,.txt"
            onChange={handleFileChange}
            disabled={isProcessing}
          />
        </label>
      </div>
    </div>
  );
}
