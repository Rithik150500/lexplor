'use client';

import type * as React from 'react';
import { useEffect, useRef } from 'react';
import { PlusCircleIcon } from 'lucide-react';
import Link from 'next/link';

import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarRail,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { useAuth } from '@clerk/nextjs';
import { useStore } from '@/lib/store';
import { useUserProfile } from './user-profile-provider';
import { useSidebarStore } from '@/lib/sidebar-store';
import { useRouter } from 'next/navigation';

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const { userProfile } = useUserProfile();
  const { open: storeOpen, setOpen } = useSidebarStore();
  const { open, toggleSidebar } = useSidebar();
  const router = useRouter();

  // Ref to track if initial sync has happened
  const initialSyncDone = useRef(false);

  // Sync the sidebar UI state with our Zustand store on initial render
  useEffect(() => {
    // Skip if running on server
    if (typeof window === 'undefined') return;

    // Wait for hydration to complete
    const timer = setTimeout(() => {
      if (!initialSyncDone.current) {
        // If the sidebar UI state doesn't match our store state, update the UI
        if (open !== storeOpen) {
          console.log('Initial sync: Setting sidebar to', storeOpen ? 'open' : 'closed');
          toggleSidebar();
        }
        initialSyncDone.current = true;
      }
    }, 0);

    return () => clearTimeout(timer);
  }, [storeOpen]); // Depend on storeOpen to re-run if it changes during hydration

  // Update our Zustand store when the sidebar UI state changes
  useEffect(() => {
    // Skip if running on server or if initial sync hasn't happened
    if (typeof window === 'undefined' || !initialSyncDone.current) return;

    // Only update the store if the state actually changed
    if (open !== storeOpen) {
      console.log('Updating store: Setting sidebar to', open ? 'open' : 'closed');
      setOpen(open);
    }
  }, [open, storeOpen, setOpen]);

  // Default user data if profile is not loaded yet
  const userData = {
    name: userProfile?.firstName
      ? `${userProfile.firstName} ${userProfile.lastName || ''}`
      : 'LeXploR User',
    email: userProfile?.email || '',
    avatar: userProfile?.imageUrl || '',
  };

  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarTrigger />
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              tooltip="Home"
              onClick={() => {
                router.push('/cocounsel');

                // Clear the Zustand store when navigating to home
                useStore.getState().resetSession();
              }}
            >
              <span className="text-xl font-bold text-primary">LeXploR</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem key="new-research-button">
            <SidebarMenuButton
              tooltip="New Research"
              onClick={() => {
                router.push('/cocounsel');

                // Clear the Zustand store when navigating to home
                useStore.getState().resetSession();
              }}
              className="flex w-full items-center gap-2 bg-primary text-primary-foreground transition-colors hover:bg-background/50 hover:text-foreground active:bg-primary/80 group-data-[collapsible=icon]:mx-2 group-data-[collapsible=icon]:h-8 group-data-[collapsible=icon]:w-8 group-data-[collapsible=icon]:justify-center"
            >
              <PlusCircleIcon className="h-4 w-4 shrink-0" />
              <span className="group-data-[collapsible=icon]:hidden">New Legal Research</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <NavMain />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={userData} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
