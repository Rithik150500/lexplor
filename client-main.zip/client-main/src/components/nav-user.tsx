'use client';
import { ChevronsUpDown, History, LogOut, User } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { UserButton, useClerk } from '@clerk/nextjs';
import { useTheme } from 'next-themes';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';

declare global {
  interface Window {
    Clerk?: {
      openUserProfile: () => void;
    };
  }
}

export function NavUser({
  user,
}: {
  user: {
    name: string;
    email: string;
    avatar: string;
  };
}) {
  const { isMobile } = useSidebar();
  const router = useRouter();
  const { signOut } = useClerk();
  const { theme } = useTheme();

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  const initials = getInitials(user.name || 'User');

  const handleProfileClick = () => {
    // Use Clerk's openUserProfile method instead of ref
    window.Clerk?.openUserProfile();
  };

  const handleSignOut = () => {
    signOut(() => router.push('/sign-in'));
  };

  // Define Clerk appearance focused on the modal styling
  const clerkAppearance = {
    variables: {
      // Using Claude's color scheme from globals.css
      colorPrimary: 'hsl(15 63.1% 59.6%)', // --primary
      colorTextOnPrimaryBackground: 'hsl(0 0% 100%)', // --primary-foreground
      colorBackground: 'hsl(60 2.1% 18.4%)', // --background
      colorText: 'hsl(48 33.3% 97.1%)', // --foreground
      colorInputBackground: 'hsl(60 2.7% 14.5%)', // --input
      colorInputText: 'hsl(48 33.3% 97.1%)', // --foreground
      colorDanger: 'hsl(0 73.1% 66.5%)', // --destructive
      colorSuccess: 'hsl(15 55.6% 52.4%)', // --success
      colorWarning: 'hsl(251 84.6% 74.5%)', // --warning
      fontFamily: 'var(--font-sans)',
      borderRadius: '0.25rem',
    },
    elements: {
      // Modal specific styling
      card: 'shadow-md border-2 border-border bg-card text-card-foreground',
      modalBackdrop: 'backdrop-blur-sm bg-black/50',
      modalCloseButton: 'hover:bg-muted rounded-full p-1',

      // Modal header
      headerTitle: 'text-xl font-bold text-foreground',
      headerSubtitle: 'text-muted-foreground',

      // Modal content and sections
      profileSectionTitle: 'text-lg font-semibold text-foreground',
      profileSectionPrimaryButton:
        'bg-primary text-primary-foreground hover:bg-primary/90 shadow-md',
      profileSectionSecondaryButton:
        'bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-md',

      // Form elements inside modal
      formButtonPrimary: 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-md',
      formButtonReset:
        'bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-md',
      formFieldLabel: 'text-sm font-medium text-foreground',
      formFieldInput: 'bg-input text-foreground border border-border shadow-inner',
      formFieldErrorText: 'text-destructive text-sm',
      formFieldSuccessText: 'text-success text-sm',

      // Avatar in modal
      userPreviewAvatarBox: 'ring-2 ring-primary',
      userPreviewAvatarContainer: 'bg-card',
      userPreviewMainIdentifier: 'font-bold text-foreground',
      userPreviewSecondaryIdentifier: 'text-muted-foreground text-sm',

      // Tabs in modal
      alternativeMethodSelector: 'bg-muted text-muted-foreground',
      alternativeMethodSelectorActive: 'bg-background text-foreground',

      // Footer
      footer: 'border-t border-border bg-card',
      footerActionLink: 'text-primary hover:text-primary/80',
      footerActionText: 'text-muted-foreground',

      // Dividers
      dividerLine: 'bg-border',
      dividerText: 'bg-card text-muted-foreground px-2',

      // Alerts and messages
      alert: 'bg-muted border border-border text-foreground',
      alertText: 'text-foreground',
      alertTextDanger: 'text-destructive',

      // Ensure the button itself is hidden
      rootBox: 'w-full flex items-center',
      avatarBox: 'hidden',
      userButtonBox: 'w-full flex items-center',
      userButtonOuterIdentifier: 'flex-1',
      userButtonTrigger: 'w-full flex items-center',
    },
  };

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton
              size="lg"
              className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
            >
              <Avatar className="h-8 w-8 rounded-lg">
                <AvatarImage src={user.avatar || '/placeholder.svg'} alt={user.name} />
                <AvatarFallback className="rounded-lg">{initials}</AvatarFallback>
              </Avatar>
              <div className="grid flex-1 text-left text-sm leading-tight">
                <span className="truncate font-semibold">{user.name}</span>
                <span className="truncate text-xs">{user.email}</span>
              </div>
              <ChevronsUpDown className="ml-auto size-4" />
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
            side={isMobile ? 'bottom' : 'right'}
            align="end"
            sideOffset={4}
          >
            <DropdownMenuLabel className="p-0 font-normal">
              <div className="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
                <Avatar className="h-8 w-8 rounded-lg">
                  <AvatarImage src={user.avatar || '/placeholder.svg'} alt={user.name} />
                  <AvatarFallback className="rounded-lg">{initials}</AvatarFallback>
                </Avatar>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-semibold">{user.name}</span>
                  <span className="truncate text-xs">{user.email}</span>
                </div>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              {/* Hidden UserButton that will be triggered programmatically */}
              <div className="hidden">
                <UserButton
                  signInUrl="/sign-in"
                  userProfileMode="modal"
                  afterSignOutUrl="/sign-in"
                  appearance={clerkAppearance}
                />
              </div>

              {/* Custom Profile menu item that triggers the UserButton */}
              <DropdownMenuItem onClick={handleProfileClick} className="cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>

              <DropdownMenuItem onClick={() => router.push('/history')} className="cursor-pointer">
                <History className="mr-2 h-4 w-4" />
                History
              </DropdownMenuItem>
            </DropdownMenuGroup>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={handleSignOut}
              className="cursor-pointer text-destructive focus:text-destructive"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
