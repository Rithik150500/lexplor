'use client';

import type React from 'react';

import { ChevronRight, History, Home, Search, Settings, User } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from '@/components/ui/sidebar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useStore } from '@/lib/store';
import { formatTimeAgo } from '@/lib/utils';

// Define types for our navigation items
interface NavItem {
  id: string;
  title: string;
  url: string;
  updatedAt?: string | Date;
}

interface NavSection {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  isActive: boolean;
  items: NavItem[];
}

export function NavMain() {
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();
  const { sessions, fetchUserSessions, currentUserId } = useStore();
  const MAX_HISTORY_ITEMS = 10;

  useEffect(() => {
    if (currentUserId) {
      fetchUserSessions();
    }
  }, [currentUserId, fetchUserSessions]);

  // Get recent sessions for the sidebar
  const recentSessions = sessions.slice(0, MAX_HISTORY_ITEMS).map((session) => ({
    id: session.id,
    title: session.title,
    updatedAt: session.updatedAt,
  }));

  const filteredSessions = recentSessions.filter((session) =>
    session.title.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const navigationItems: NavSection[] = [
    {
      id: 'research-section',
      title: 'Recent Research',
      icon: History,
      isActive: true,
      items: filteredSessions.map((session) => ({
        id: session.id,
        title: session.title,
        url: `/analysis/${session.id}`,
        updatedAt: session.updatedAt,
      })),
    },
  ];

  return (
    <SidebarGroup>
      <SidebarMenu>
        {navigationItems.map((section) => (
          <Collapsible
            key={section.id}
            asChild
            defaultOpen={section.isActive}
            className="group/collapsible"
          >
            <SidebarMenuItem>
              <CollapsibleTrigger asChild>
                <SidebarMenuButton tooltip={section.title}>
                  {section.icon && <section.icon className="h-4 w-4" />}
                  <span>{section.title}</span>
                  <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <div className="space-y-1">
                  <SidebarMenuSub>
                    {section.title === 'Recent Research' && (
                      <div className="relative mb-2">
                        <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                        <Input
                          placeholder="Search research..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-8"
                        />
                      </div>
                    )}
                    {section.items?.map((item) => (
                      <SidebarMenuSubItem key={item.id}>
                        <SidebarMenuSubButton asChild>
                          <Link href={item.url}>
                            <span className="truncate">{item.title}</span>
                            {item.updatedAt && (
                              <span className="ml-auto text-xs text-muted-foreground">
                                {formatTimeAgo(new Date(item.updatedAt))}
                              </span>
                            )}
                          </Link>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    ))}
                    {section.title === 'Recent Research' && sessions.length > MAX_HISTORY_ITEMS && (
                      <SidebarMenuSubItem key="view-all-history">
                        <SidebarMenuSubButton asChild>
                          <Button
                            variant="ghost"
                            className="w-full justify-start"
                            onClick={() => router.push('/history')}
                          >
                            View All History
                          </Button>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    )}
                  </SidebarMenuSub>
                </div>
              </CollapsibleContent>
            </SidebarMenuItem>
          </Collapsible>
        ))}
      </SidebarMenu>
    </SidebarGroup>
  );
}
