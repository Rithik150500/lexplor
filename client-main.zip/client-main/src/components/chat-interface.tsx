'use client';

import type React from 'react';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion as m } from 'framer-motion';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Bot, MessageSquare, X, FileText, Upload, AlertCircle, Copy } from 'lucide-react';
import { useStore } from '@/lib/store';
import { useAuth } from '@clerk/nextjs';
import { FileUpload } from '@/components/file-upload';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { marked } from 'marked';

export function ChatInterface() {
  const router = useRouter();
  const { userId } = useAuth();
  const {
    currentSession,
    isProcessing,
    createNewSession,
    submitLegalProblem,
    setCaseFile,
    setCurrentUserId,
  } = useStore();

  const [input, setInput] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [fileData, setFileData] = useState<{
    name: string;
    content: string;
    isBinary: boolean;
  } | null>(null);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('legal-matter');
  const [error, setError] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const messages = currentSession?.messages || [];

  // Enhanced animation variants with reduced motion
  const containerVariants = {
    empty: {
      height: '100%',
    },
    expanded: {
      height: '100%',
    },
  };

  // Less dramatic message animation to reduce flickering
  const messageVariants = {
    initial: {
      opacity: 0,
      y: 10,
    },
    animate: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.2,
      },
    },
    exit: {
      opacity: 0,
      transition: {
        duration: 0.1,
      },
    },
  };

  const inputVariants = {
    empty: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 250,
        damping: 30,
      },
    },
    expanded: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 250,
        damping: 30,
      },
    },
  };

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    // Set current user ID
    if (userId) {
      setCurrentUserId(userId);
    }
  }, [userId, setCurrentUserId]);

  useEffect(() => {
    // Create a new session if none exists
    if (!currentSession && userId) {
      createNewSession();
    }
  }, [currentSession, createNewSession, userId]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleInputFocus = () => {
    setExpanded(true);
  };

  const handleFileProcessed = (content: string, fileName: string) => {
    setFileData({
      name: fileName,
      content,
      isBinary: false,
    });
    setShowFileUpload(false);
    setActiveTab('legal-matter'); // Switch back to legal matter tab after file upload
    setError(null);
  };

  const handleFileError = (errorMessage: string) => {
    setError(errorMessage);
  };

  const handleRemoveFile = () => {
    setFileData(null);
    setError(null);
  };

  const handleSubmit = async () => {
    if (isProcessing) return;

    // Validate input
    if (!input.trim()) {
      setError('Please enter your legal matter before submitting.');
      setActiveTab('legal-matter');
      return;
    }

    // Combine the legal matter (input) and case file content (if any) into a single dispute string
    let combinedDispute = input.trim();

    if (fileData && fileData.content) {
      // Add a separator between legal matter and case file content
      combinedDispute += '\n\n--- CASE FILE: ' + fileData.name + ' ---\n\n' + fileData.content;

      // Store the case file separately if needed
      setCaseFile(fileData.content, {
        name: fileData.name,
        isBinary: fileData.isBinary,
      });
    }

    // Submit the combined dispute as the legal problem
    await submitLegalProblem(combinedDispute);

    // Clear input and file data
    setInput('');
    setFileData(null);
    setError(null);

    // Navigate to analysis page
    if (currentSession) {
      router.push(`/analysis/${currentSession.id}`, { scroll: false });
    }
  };

  return (
    <m.div
      variants={containerVariants}
      initial="empty"
      animate={expanded ? 'expanded' : 'empty'}
      className="flex h-full w-full flex-col bg-background"
    >
      <div className="flex w-full flex-col items-center border-b border-border bg-card p-8 shadow-sm">
        <div className="mb-8 flex w-full max-w-3xl items-center justify-between">
          <h1 className="text-4xl font-bold text-primary">LeXploR</h1>
        </div>

        <div className="w-full max-w-3xl">
          <Card className="border-border shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Submit Your Legal Research</CardTitle>
              <CardDescription>
                Enter your legal matter and optionally upload a case file for analysis
              </CardDescription>
            </CardHeader>

            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-4 grid grid-cols-2">
                  <TabsTrigger value="legal-matter" className="text-sm">
                    <FileText className="mr-2 h-4 w-4" />
                    Legal Matter
                  </TabsTrigger>
                  <TabsTrigger value="case-file" className="text-sm">
                    <Upload className="mr-2 h-4 w-4" />
                    Case File {fileData && '(1)'}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="legal-matter" className="mt-0">
                  <div className="space-y-2">
                    <Textarea
                      ref={textareaRef}
                      value={input}
                      onChange={(e) => {
                        setInput(e.target.value);
                        if (e.target.value.trim()) {
                          setError(null);
                        }
                      }}
                      onKeyDown={handleKeyDown}
                      onFocus={handleInputFocus}
                      placeholder="Enter your legal matter or question here..."
                      className="max-h-[300px] min-h-[150px] w-full resize-none overflow-y-auto rounded-lg border border-border bg-background p-4 text-foreground shadow-sm transition-all duration-200 placeholder:text-muted-foreground focus:ring-2 focus:ring-primary/20"
                    />

                    {fileData && (
                      <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/50 p-3">
                        <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md bg-primary/10">
                          <FileText className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-foreground">{fileData.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {Math.round(fileData.content.length / 1000)}K characters
                          </p>
                        </div>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={handleRemoveFile}
                          className="h-8 w-8 rounded-full hover:bg-destructive/10 hover:text-destructive"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="case-file" className="mt-0">
                  <div className="space-y-4">
                    {fileData ? (
                      <div className="overflow-hidden rounded-lg border border-border">
                        <div className="flex items-center justify-between border-b border-border bg-muted p-3">
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-primary" />
                            <span className="text-sm font-medium">{fileData.name}</span>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleRemoveFile}
                            className="h-8 text-xs hover:bg-destructive/10 hover:text-destructive"
                          >
                            <X className="mr-1 h-3 w-3" /> Remove
                          </Button>
                        </div>
                        <ScrollArea className="h-[200px]">
                          <div className="whitespace-pre-wrap p-4 font-mono text-sm">
                            <div
                              dangerouslySetInnerHTML={{
                                __html: marked(fileData.content, {
                                  gfm: true,
                                  breaks: true,
                                }),
                              }}
                            />
                          </div>
                        </ScrollArea>
                      </div>
                    ) : (
                      <FileUpload onFileProcessed={handleFileProcessed} onError={handleFileError} />
                    )}

                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Error</AlertTitle>
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>

            <CardFooter className="flex justify-between pt-2">
              <div className="text-xs text-muted-foreground">
                {fileData
                  ? 'Case file will be analyzed together with your legal matter'
                  : 'Case file upload is optional'}
              </div>
              <Button
                onClick={handleSubmit}
                disabled={isProcessing || (!input.trim() && !fileData)}
                className="rounded-lg bg-primary px-6 py-2 font-semibold tracking-wide text-primary-foreground shadow-md transition-all duration-200 ease-in-out hover:bg-primary/90 hover:shadow-lg active:shadow-sm disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <span className="animate-pulse">Processing</span>
                    <div className="flex gap-1">
                      <span className="animate-bounce delay-0">.</span>
                      <span className="animate-bounce delay-150">.</span>
                      <span className="animate-bounce delay-300">.</span>
                    </div>
                  </div>
                ) : (
                  <span className="flex items-center gap-2">
                    <Bot className="h-4 w-4" />
                    Analyze with LeXploR
                  </span>
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      {!messages.length || (messages.length === 1 && messages[0].role === 'assistant') ? (
        <div className="flex-1 bg-muted p-8">
          <div className="mx-auto max-w-3xl rounded-lg border border-border bg-card/50 p-8 shadow-lg backdrop-blur-sm">
            <h2 className="mb-6 text-xl font-bold text-primary-foreground">
              Enter Your Legal Problem Above:
            </h2>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary">
                  <MessageSquare className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="mb-2 font-semibold text-foreground">Click "LeXploR"</h3>
                  <p className="text-muted-foreground">
                    Initiate an AI-powered analysis tailored to your legal problem.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary">
                  <Bot className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="mb-2 font-semibold text-foreground">Receive a Detailed Memo</h3>
                  <p className="text-muted-foreground">
                    Get a professionally structured legal memo with relevant laws and precedents.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary">
                  <MessageSquare className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="mb-2 font-semibold text-foreground">
                    Engage with Our AI Assistant
                  </h3>
                  <p className="text-muted-foreground">
                    Dive deeper by chatting with our AI for clarifications and further insights.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary">
                  <Copy className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="mb-2 font-semibold text-foreground">Explore Relevant Cases</h3>
                  <p className="text-muted-foreground">
                    Access summaries and full texts of pertinent cases, with key sections
                    highlighted.
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-8 text-center italic text-muted-foreground">
              Experience a smarter way to conduct legal research. Start by entering your legal
              problem above!
            </p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-8 py-16">
          <div className="flex flex-col items-center gap-4">
            <div className="relative flex w-72 flex-col gap-2">
              <div className="flex items-center gap-3">
                <span className="h-3 w-3 animate-pulse rounded-full bg-primary" />
                <span className="text-base font-medium text-foreground">
                  Generating relevant cases...
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="h-3 w-3 animate-pulse rounded-full bg-primary/80 [animation-delay:200ms]" />
                <span className="text-base font-medium text-foreground">
                  Generating partial memo...
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="h-3 w-3 animate-pulse rounded-full bg-primary/60 [animation-delay:400ms]" />
                <span className="text-base font-medium text-foreground">
                  Generated doc titles...
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="h-3 w-3 animate-pulse rounded-full bg-primary/40 [animation-delay:600ms]" />
                <span className="text-base font-medium text-foreground">
                  Generating final memo...
                </span>
              </div>
            </div>
          </div>
          <div className="mt-6 flex items-center gap-2">
            <svg
              className="h-6 w-6 animate-spin text-primary"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
            </svg>
            <span className="text-muted-foreground">AI is preparing your legal analysis...</span>
          </div>
        </div>
      )}
    </m.div>
  );
}
