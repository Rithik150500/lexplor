'use client';

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { useAuth, useUser } from '@clerk/nextjs';

interface UserProfile {
  id: string;
  email: string | null;
  phoneNumber: string | null;
  firstName: string | null;
  lastName: string | null;
  imageUrl: string | null;
  lastSignedIn: string | null;
  createdAt: string;
  updatedAt: string;
}

interface UserProfileContextType {
  userProfile: UserProfile | null;
  isLoading: boolean;
  error: string | null;
  refetchProfile: () => Promise<void>;
}

const UserProfileContext = createContext<UserProfileContextType>({
  userProfile: null,
  isLoading: false,
  error: null,
  refetchProfile: async () => {},
});

export const useUserProfile = () => useContext(UserProfileContext);

export function UserProfileProvider({ children }: { children: ReactNode }) {
  const { userId, isLoaded: isAuthLoaded } = useAuth();
  const { user, isLoaded: isUserLoaded } = useUser();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUserProfile = async () => {
    if (!userId) return null;

    try {
      const response = await fetch(`/api/user`);
      if (!response.ok) {
        throw new Error('Failed to fetch user profile');
      }
      return await response.json();
    } catch (err) {
      console.error('Error fetching user profile:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      return null;
    }
  };

  const refetchProfile = async () => {
    if (!userId) return;

    setIsLoading(true);
    const profile = await fetchUserProfile();
    if (profile) {
      setUserProfile(profile);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    const syncUserWithDatabase = async () => {
      if (!userId || !isAuthLoaded || !isUserLoaded || !user) return;

      setIsLoading(true);
      setError(null);

      try {
        // Prepare user data from Clerk
        const userData = {
          email: user.primaryEmailAddress?.emailAddress || null,
          phoneNumber: user.primaryPhoneNumber?.phoneNumber || null,
          firstName: user.firstName,
          lastName: user.lastName,
          imageUrl: user.imageUrl,
        };

        // Save user data to our database
        const response = await fetch('/api/user', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(userData),
        });

        if (!response.ok) {
          throw new Error('Failed to sync user data');
        }

        const savedUser = await response.json();
        setUserProfile(savedUser);
      } catch (err) {
        console.error('Error syncing user data:', err);
        setError(err instanceof Error ? err.message : 'Unknown error occurred');

        // Try to fetch existing profile if sync fails
        const profile = await fetchUserProfile();
        if (profile) {
          setUserProfile(profile);
        }
      } finally {
        setIsLoading(false);
      }
    };

    syncUserWithDatabase();
  }, [userId, isAuthLoaded, isUserLoaded, user]);

  return (
    <UserProfileContext.Provider value={{ userProfile, isLoading, error, refetchProfile }}>
      {children}
    </UserProfileContext.Provider>
  );
}
