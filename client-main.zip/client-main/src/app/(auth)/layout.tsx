import React from 'react';

export default function layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Left column - Sign In */}
      <div className="flex w-full items-center justify-center p-4 sm:p-6 md:p-8 lg:w-1/2">
        <div className="w-full max-w-md">{children}</div>
      </div>

      {/* Right column - Company Info */}
      <div className="hidden flex-col justify-center bg-gradient-to-br from-primary/5 to-primary/10 px-8 lg:flex lg:w-1/2 xl:px-16">
        <div className="max-w-lg">
          <h1 className="mb-4 text-4xl font-bold text-foreground xl:mb-6 xl:text-5xl">Lexplor</h1>
          <p className="mb-6 text-lg leading-relaxed text-muted-foreground xl:mb-8 xl:text-xl">
            Welcome to Lexplor, your gateway to seamless legal exploration. We're dedicated to
            revolutionizing how you access and understand legal information. Sign in to unlock a
            world of legal insights and resources at your fingertips.
          </p>
          <div className="flex items-center space-x-4">
            <div className="h-1 w-16 rounded-full bg-primary"></div>
            <p className="text-sm text-muted-foreground">
              Empowering legal professionals worldwide
            </p>
          </div>
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 xl:mt-12 xl:gap-8">
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <svg
                  className="h-5 w-5 text-primary"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                  />
                </svg>
              </div>
              <span className="font-medium text-foreground">Secure Platform</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <svg
                  className="h-5 w-5 text-primary"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                  />
                </svg>
              </div>
              <span className="font-medium text-foreground">Comprehensive Database</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
