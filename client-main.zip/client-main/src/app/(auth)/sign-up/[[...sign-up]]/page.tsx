import { SignUp } from '@clerk/nextjs';

export default function SignUpPage() {
  return (
    <SignUp
      afterSignOutUrl="/sign-in"
      appearance={{
        elements: {
          rootBox: 'w-full',
          card: 'bg-background border-none',
          cardBox: 'bg-transparent',
          headerTitle: 'text-foreground text-2xl sm:text-3xl font-bold mb-2',
          headerSubtitle: 'text-muted-foreground text-sm sm:text-base',
          socialButtonsBlockButton:
            'bg-background border border-border text-foreground hover:bg-muted/50 transition-colors',
          socialButtonsProviderIcon: 'h-5 w-5',
          dividerLine: 'bg-border',
          dividerText: 'text-muted-foreground',
          formFieldLabel: 'text-foreground font-medium',
          formFieldInput:
            'bg-background border border-border text-foreground rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent',
          formFieldInputShowPasswordButton: 'text-muted-foreground hover:text-foreground',
          formButtonPrimary:
            'bg-primary text-primary-foreground hover:bg-primary/90 transition-colors rounded-lg',
          footerActionText: 'text-muted-foreground',
          footerActionLink: 'text-primary hover:text-primary/80 transition-colors',
          identityPreview: 'bg-background border border-border rounded-lg',
          identityPreviewText: 'text-foreground',
          identityPreviewEditButton: 'text-primary hover:text-primary/80 transition-colors',
          alternativeMethodsBlockButton: 'text-primary hover:text-primary/80 transition-colors',
          formFieldWarningText: 'text-warning',
          formFieldErrorText: 'text-error',
          otpCodeBoxInput:
            'bg-background border border-border text-foreground rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent',
          otpCodeBoxInputFocused: 'ring-2 ring-primary',
        },
        layout: {
          socialButtonsVariant: 'iconButton',
          socialButtonsPlacement: 'top',
        },
      }}
      signInUrl="/sign-in"
    />
  );
}
