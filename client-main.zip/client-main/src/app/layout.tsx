import type React from 'react';
import type { Metadata } from 'next';
import { Mona_Sans as FontSans, Young_Serif as FontSerif } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { AppSidebar } from '@/components/app-sidebar';
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import {
  ClerkProvider,
  SignInButton,
  SignUpButton,
  SignedIn,
  SignedOut,
  UserButton,
} from '@clerk/nextjs';
import { UserProfileProvider } from '@/components/user-profile-provider';

const fontSans = FontSans({
  subsets: ['latin'],
  variable: '--font-sans',
});

const fontSerif = FontSerif({
  subsets: ['latin'],
  weight: ['400'],
  variable: '--font-serif',
});

export const metadata: Metadata = {
  title: 'LexPlor - Legal Research Platform',
  description: 'AI-powered legal research and analysis platform',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider signInUrl="/sign-in" signUpUrl="/sign-up" afterSignOutUrl="/sign-in">
      <UserProfileProvider>
        <html lang="en" suppressHydrationWarning>
          <body className={`${fontSans.variable} ${fontSerif.variable} bg-background font-sans`}>
            <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
              {children}
            </ThemeProvider>
          </body>
        </html>
      </UserProfileProvider>
    </ClerkProvider>
  );
}
