'use client';
import { buttonVariants } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Home, Menu, X, Search } from 'lucide-react';
import { UserButton } from '@clerk/nextjs';
import Link from 'next/link';
import { marked } from 'marked';
import Markdown from 'markdown-to-jsx';
import { useEffect, useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface TableOfContentsItem {
  id: string;
  text: string;
  level: number;
}

// Helper to generate a valid id string from heading children
function getHeadingId(children: string | React.ReactNode): string | undefined {
  if (typeof children === 'string') {
    const id = children.toLowerCase().replace(/\s+/g, '-');
    return id || undefined;
  }
  return undefined;
}

export default function DocsPage({ documentation }: { documentation: string }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [tableOfContents, setTableOfContents] = useState<TableOfContentsItem[]>([]);
  const [activeSection, setActiveSection] = useState('');

  // Extract headings for table of contents
  useEffect(() => {
    const extractHeadings = async () => {
      const headings: TableOfContentsItem[] = [];
      const parser = new DOMParser();
      const html = await marked(documentation);
      const doc = parser.parseFromString(html, 'text/html');

      doc.querySelectorAll('h2, h3').forEach((heading) => {
        const id = heading.textContent?.toLowerCase().replace(/\s+/g, '-') ?? '';
        headings.push({
          id,
          text: heading.textContent ?? '',
          level: heading.tagName === 'H2' ? 2 : 3,
        });
      });

      setTableOfContents(headings);
    };

    extractHeadings();
  }, [documentation]);

  // Handle scroll to track active section
  useEffect(() => {
    const handleScroll = () => {
      const headingElements = document.querySelectorAll('h2, h3');

      for (let i = headingElements.length - 1; i >= 0; i--) {
        const heading = headingElements[i];
        const rect = heading.getBoundingClientRect();

        if (rect.top <= 100) {
          const id = heading.id || (heading.textContent?.toLowerCase().replace(/\s+/g, '-') ?? '');
          setActiveSection(id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      }
    }
  };

  return (
    <main className="flex min-h-screen flex-col bg-gradient-to-br from-background via-background to-muted/30">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-card/95 px-4 py-4 shadow-sm backdrop-blur-sm md:px-8">
        <div className="flex items-center gap-2 md:gap-4">
          <button
            className="rounded-md p-2 transition-colors hover:bg-muted md:hidden"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <Link href="/" className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold tracking-tight text-primary drop-shadow-sm md:text-3xl">
              LeXploR
            </h1>
          </Link>
          <span className="hidden text-sm font-medium text-muted-foreground sm:inline-block md:text-lg">
            Documentation
          </span>
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <Link
            href="/"
            className={buttonVariants({
              variant: 'outline',
              size: 'sm',
              className:
                'hidden items-center gap-2 shadow-sm transition-colors hover:bg-accent sm:flex',
            })}
          >
            <Home className="h-4 w-4" />
            Home
          </Link>
          <UserButton />
        </div>
      </header>

      <div className="relative flex flex-1">
        {/* Mobile sidebar overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-background/80 backdrop-blur-sm md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={`fixed top-[65px] z-20 h-[calc(100vh-65px)] w-72 border-r border-border bg-card/90 p-5 transition-transform duration-300 md:sticky ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
          }`}
        >
          <ScrollArea className="h-full">
            <div className="space-y-1">
              <p className="mb-2 text-sm font-medium text-muted-foreground">On this page</p>
              {tableOfContents.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`block w-full rounded-md px-3 py-1.5 text-left text-sm transition-colors ${
                    activeSection === item.id
                      ? 'bg-primary/10 font-medium text-primary'
                      : 'hover:bg-muted'
                  } ${item.level === 3 ? 'pl-6' : ''}`}
                >
                  {item.text}
                </button>
              ))}
            </div>
          </ScrollArea>
        </aside>

        {/* Main content */}
        <div className="w-full flex-1 px-4 py-8 md:ml-0 md:px-8">
          <div className="w-full overflow-hidden border border-border bg-card">
            <div className="p-6 md:p-8 lg:p-10">
              <Markdown
                options={{
                  overrides: {
                    a: {
                      props: {
                        className:
                          'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                        target: '_blank',
                        rel: 'noopener noreferrer',
                      },
                    },
                    h1: {
                      props: {
                        className:
                          'text-2xl font-bold mt-8 mb-4 text-foreground border-b pb-2 border-border/40 scroll-mt-20',
                        id: ({ children }: { children: React.ReactNode }) => getHeadingId(children),
                      },
                    },
                    h2: {
                      props: {
                        className: 'text-xl font-semibold mt-6 mb-3 text-foreground scroll-mt-20',
                        id: ({ children }: { children: React.ReactNode }) => getHeadingId(children),
                      },
                    },
                    h3: {
                      props: {
                        className: 'text-lg font-medium mt-5 mb-2 text-foreground scroll-mt-20',
                        id: ({ children }: { children: React.ReactNode }) => getHeadingId(children),
                      },
                    },
                    p: {
                      props: {
                        className: 'text-base leading-relaxed mb-4 text-foreground',
                      },
                    },
                    ul: {
                      props: {
                        className: 'list-disc pl-6 mb-4 space-y-2',
                      },
                    },
                    ol: {
                      props: {
                        className: 'list-decimal pl-6 mb-4 space-y-2',
                      },
                    },
                    li: {
                      props: {
                        className: 'text-base text-foreground',
                      },
                    },
                    blockquote: {
                      props: {
                        className:
                          'border-l-4 border-primary/30 pl-4 py-2 italic my-4 bg-muted/30 rounded-r-sm text-muted-foreground',
                      },
                    },
                    code: {
                      props: {
                        className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                      },
                    },
                    pre: {
                      props: {
                        className:
                          'bg-muted p-4 rounded-lg overflow-x-auto my-4 font-mono text-sm border border-border/50',
                      },
                    },
                    table: {
                      props: {
                        className:
                          'min-w-full divide-y divide-border mb-4 text-base border border-border/30 rounded-lg overflow-hidden',
                      },
                    },
                    thead: {
                      props: {
                        className: 'bg-muted/50',
                      },
                    },
                    th: {
                      props: {
                        className:
                          'px-4 py-2.5 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                      },
                    },
                    td: {
                      props: {
                        className: 'px-4 py-2.5 text-sm text-foreground border-t border-border/20',
                      },
                    },
                    img: {
                      props: {
                        className: 'rounded-lg shadow-md max-w-full my-4 border border-border/40',
                      },
                    },
                    hr: {
                      props: {
                        className: 'my-8 border-t border-border',
                      },
                    },
                  },
                }}
              >
                {documentation}
              </Markdown>
            </div>
          </div>

          <footer className="mt-12 text-center text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} LeXploR. All rights reserved.</p>
          </footer>
        </div>
      </div>
    </main>
  );
}
