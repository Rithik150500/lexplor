import { readFileSync } from 'fs';
import React from 'react';
import DocsPage from './page.client';
import { join } from 'path';

export default function Page() {
  const documentation = readFileSync(join(process.cwd(), 'src/app/(landing)/docs/doc.md'), 'utf-8');

  return <DocsPage documentation={documentation} />;
}
