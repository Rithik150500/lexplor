'use client';
import Link from 'next/link';
import { Search, LineChart, FileCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UserButton, useAuth } from '@clerk/nextjs';
import Image from 'next/image';

export default function LandingPage() {
  const { isSignedIn } = useAuth();
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="container mx-auto flex items-center justify-between py-6">
        <div className="font-serif text-4xl font-bold text-foreground">LeXploR</div>
        <div className="hidden text-lg text-muted-foreground md:block">
          Human legal thinking backed by AI powered precision
        </div>
        <div className="flex items-center gap-x-4">
          {isSignedIn ? (
            <UserButton />
          ) : (
            <>
              <Link href="/sign-in">
                <Button variant="ghost" className="text-foreground">
                  Sign In
                </Button>
              </Link>
              <Link href="/sign-up">
                <Button>Sign Up</Button>
              </Link>
            </>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto py-16 md:py-24">
        <div className="grid grid-cols-1 items-center gap-8 md:grid-cols-2">
          <div>
            <h1 className="mb-6 font-serif text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
              Human legal thinking backed by AI powered precision
            </h1>
            <p className="mb-8 text-xl text-muted-foreground">
              LeXploR is your AI-powered legal research companion— crafted to streamline case law
              search, formulate strategies, and build robust legal arguments.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              {isSignedIn ? (
                <Link href="/cocounsel">
                  <Button size="lg" className="w-full sm:w-auto">
                    Continue Analysis
                  </Button>
                </Link>
              ) : (
                <Link href="/sign-up">
                  <Button size="lg" className="w-full sm:w-auto">
                    Start LexPloring
                  </Button>
                </Link>
              )}
              <Link href="/docs">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  See How It Works
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative hidden md:block">
            <div className="relative h-[400px] w-full">
              <Image
                src="/lawyer-laptop-speech.png"
                width={500}
                height={500}
                alt="Hero Image"
                className="object-cover"
              />
            </div>
            <div className="absolute right-[-20px] top-[-20px] z-0 h-64 w-64 rounded-full bg-primary/5"></div>
          </div>
        </div>
      </section>

      {/* Why LeXploR Section */}
      <section className="bg-muted/30 py-16 md:py-24" id="how-it-works">
        <div className="container mx-auto">
          <div className="mb-12 flex flex-col items-center justify-between md:flex-row">
            <h2 className="font-serif text-3xl font-bold md:text-4xl">Why LeXploR</h2>
            <p className="mt-2 text-xl text-muted-foreground md:mt-0">
              Designed for the sharpest legal minds
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Feature 1 */}
            <div className="rounded-lg bg-background p-6 shadow-sm">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Search className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-bold">Smart Case Law Search</h3>
              <p className="text-muted-foreground">
                Use intuitive search to find the most relevant precedents instantly.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="rounded-lg bg-background p-6 shadow-sm">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <LineChart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-bold">Strategy & Argument Builder</h3>
              <p className="text-muted-foreground">
                Frame your arguments with contextual case law suggestions.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="rounded-lg bg-background p-6 shadow-sm">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <FileCheck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-bold">Time-Saving Draft Companion</h3>
              <p className="text-muted-foreground">
                Draft smarter, not harder—LeXpioR reduces hours of manual work.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card py-8">
        <div className="container mx-auto">
          <div className="flex flex-col items-center justify-between md:flex-row">
            <div className="mb-4 font-serif text-2xl font-bold text-foreground md:mb-0">
              LeXploR
            </div>
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} LeXploR. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
