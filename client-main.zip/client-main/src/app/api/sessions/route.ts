import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { auth, getAuth } from '@clerk/nextjs/server';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const { userId } = await getAuth(request);
    const { searchParams } = new URL(request.url);
    const queryUserId = searchParams.get('userId');

    // Ensure the user is authenticated
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // If a specific userId is requested, ensure it matches the authenticated user
    if (queryUserId && queryUserId !== userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Get sessions for the authenticated user
    const sessions = await prisma.chatSession.findMany({
      where: {
        userId: userId,
      },
      orderBy: {
        updatedAt: 'desc',
      },
    });

    return NextResponse.json(sessions);
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId } = await getAuth(request);
    const data = await request.json();

    // Ensure the user is authenticated
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Ensure the session belongs to the authenticated user
    if (data.userId !== userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Check if session already exists
    const existingSession = await prisma.chatSession.findUnique({
      where: {
        id: data.id,
      },
    });

    if (existingSession) {
      // Ensure the user owns the session they're trying to update
      if (existingSession.userId !== userId) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
      }

      // Update existing session
      const updatedSession = await prisma.chatSession.update({
        where: {
          id: data.id,
        },
        data: {
          title: data.title,
          messages: data.messages,
          memo: data.memo,
          relevantCases: data.relevantCases,
          caseFile: data.caseFile,
          fileMetadata: data.fileMetadata,
          updatedAt: new Date(),
        },
      });

      return NextResponse.json(updatedSession);
    } else {
      // Create new session
      const newSession = await prisma.chatSession.create({
        data: {
          id: data.id,
          userId: userId,
          title: data.title,
          messages: data.messages,
          memo: data.memo,
          relevantCases: data.relevantCases,
          caseFile: data.caseFile,
          fileMetadata: data.fileMetadata,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      });

      return NextResponse.json(newSession);
    }
  } catch (error) {
    console.error('Error saving session:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
