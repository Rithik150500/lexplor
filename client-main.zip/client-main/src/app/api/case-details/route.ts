import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const documentId = data.document_id;
    const analysisReasoningIds = data.analysis_reasoning_ids || [];

    if (!documentId) {
      return NextResponse.json({ error: 'No document ID provided' }, { status: 400 });
    }

    // Forward the request to the Flask backend
    const response = await fetch(`${process.env.BACKEND_URL}/get_case_details`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        document_id: documentId,
        analysis_reasoning_ids: analysisReasoningIds,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      return NextResponse.json({ error: errorText }, { status: response.status });
    }

    const caseDetails = await response.json();
    return NextResponse.json(caseDetails);
  } catch (error) {
    console.error('Error fetching case details:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
