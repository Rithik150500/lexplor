import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const legalProblem = data.dispute?.trim();

    if (!legalProblem) {
      return NextResponse.json({ error: 'No legal problem provided' }, { status: 400 });
    }

    // Create a readable stream to send SSE events
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Forward the request to the Flask backend
          const response = await fetch(`${process.env.BACKEND_URL}/process_dispute_sse`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ dispute: legalProblem }),
          });

          if (!response.ok) {
            const errorText = await response.text();
            controller.enqueue(encoder.encode(`event: error\ndata: ${errorText}\n\n`));
            controller.close();
            return;
          }

          // Get the response body as a readable stream
          const reader = response.body?.getReader();
          if (!reader) {
            controller.enqueue(
              encoder.encode(`event: error\ndata: Failed to get response reader\n\n`),
            );
            controller.close();
            return;
          }

          // Read chunks from the response and forward them to the client
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            // Forward the chunk as-is
            controller.enqueue(value);
          }

          controller.close();
        } catch (error) {
          console.error('Error in SSE stream:', error);
          controller.enqueue(
            encoder.encode(
              `event: error\ndata: ${error instanceof Error ? error.message : String(error)}\n\n`,
            ),
          );
          controller.close();
        }
      },
    });

    // Return the stream as an SSE response
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    });
  } catch (error) {
    console.error('Error processing dispute:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

const encoder = new TextEncoder();
