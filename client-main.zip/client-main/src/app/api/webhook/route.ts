import { Webhook } from 'svix';
import { headers } from 'next/headers';
import type { WebhookEvent } from '@clerk/nextjs/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function POST(req: Request) {
  // Get the headers
  const headerPayload = await headers();
  const svix_id = headerPayload.get('svix-id');
  const svix_timestamp = headerPayload.get('svix-timestamp');
  const svix_signature = headerPayload.get('svix-signature');

  // If there are no svix headers, return 400
  if (!svix_id || !svix_timestamp || !svix_signature) {
    return new Response('Missing svix headers', { status: 400 });
  }

  // Get the body
  const payload = await req.json();
  const body = JSON.stringify(payload);

  // Create a new Svix instance with your webhook secret
  const wh = new Webhook(process.env.CLERK_WEBHOOK_SIGNING_SECRET || '');

  let evt: WebhookEvent;

  // Verify the webhook
  try {
    evt = wh.verify(body, {
      'svix-id': svix_id,
      'svix-timestamp': svix_timestamp,
      'svix-signature': svix_signature,
    }) as WebhookEvent;
  } catch (err) {
    console.error('Error verifying webhook:', err);
    return new Response('Error verifying webhook', { status: 400 });
  }

  // Get the event type
  const eventType = evt.type;

  console.log(`Webhook received: ${eventType}`);
  console.log('Webhook data:', JSON.stringify(evt.data, null, 2));

  try {
    // Handle the different event types
    switch (eventType) {
      case 'user.created':
        await handleUserCreated(evt.data);
        break;
      case 'user.updated':
        await handleUserUpdated(evt.data);
        break;
      case 'user.deleted':
        await handleUserDeleted(evt.data);
        break;
      case 'session.created':
        await handleSessionCreated(evt.data);
        break;
      default:
        console.log(`Unhandled event type: ${eventType}`);
    }

    // Return a 200 response
    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error(`Error processing ${eventType}:`, error);
    return new Response(JSON.stringify({ success: false, error: (error as Error).message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

// Extract user data from webhook payload
function extractUserData(userData: any) {
  const primaryEmail =
    userData.email_addresses?.find(
      (email: any) => email.id === userData.primary_email_address_id,
    ) || userData.email_addresses?.[0];

  const primaryPhone =
    userData.phone_numbers?.find((phone: any) => phone.id === userData.primary_phone_number_id) ||
    userData.phone_numbers?.[0];

  return {
    id: userData.id,
    email: primaryEmail?.email_address,
    firstName: userData.first_name,
    lastName: userData.last_name,
    phoneNumber: primaryPhone?.phone_number,
    imageUrl: userData.image_url,
    lastSignedIn: userData.last_sign_in_at ? new Date(userData.last_sign_in_at) : null,
    createdAt: userData.created_at ? new Date(userData.created_at) : new Date(),
    updatedAt: userData.updated_at ? new Date(userData.updated_at) : new Date(),
  };
}

// Handler functions for each event type
async function handleUserCreated(userData: any) {
  console.log('User created:', userData.id);

  const user = extractUserData(userData);

  // Create a new user in the database
  await prisma.user.create({
    data: user,
  });

  console.log(`User created in database: ${user.id}`);
}

async function handleUserUpdated(userData: any) {
  console.log('User updated:', userData.id);

  const user = extractUserData(userData);

  // Update the user in the database
  await prisma.user.update({
    where: { id: user.id },
    data: user,
  });

  console.log(`User updated in database: ${user.id}`);
}

async function handleUserDeleted(userData: any) {
  console.log('User deleted:', userData.id);

  // Delete the user from the database
  await prisma.user.delete({
    where: { id: userData.id },
  });

  console.log(`User deleted from database: ${userData.id}`);
}

async function handleSessionCreated(sessionData: any) {
  const userId = sessionData.user_id;
  console.log('Session created for user:', userId);

  if (!userId) {
    console.log('No user ID found in session data');
    return;
  }

  // Update the user's last signed in time
  await prisma.user.update({
    where: { id: userId },
    data: {
      lastSignedIn: new Date(),
    },
  });

  console.log(`Updated last sign-in time for user: ${userId}`);
}
