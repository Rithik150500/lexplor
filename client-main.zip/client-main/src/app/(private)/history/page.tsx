'use client';

import { useState, useEffect } from 'react';
import { Search, Plus, ChevronLeft, ChevronRight, Trash } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Checkbox } from '@/components/ui/checkbox';
import { useStore } from '@/lib/store';
import { formatTimeAgo } from '@/lib/utils';
import { useAuth } from '@clerk/nextjs';
import { useRouter } from 'next/navigation';

const ITEMS_PER_PAGE = 6;

export default function HistoryPage() {
  const { userId } = useAuth();
  const { sessions, deleteSession, deleteSessions, fetchUserSessions, setCurrentUserId } =
    useStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const loadSessions = async () => {
      try {
        if (userId) {
          setCurrentUserId(userId);
          await fetchUserSessions();
        }
        setLoading(false);
      } catch (err) {
        setError('Failed to load legal matter history');
        setLoading(false);
      }
    };

    loadSessions();
  }, [userId, fetchUserSessions, setCurrentUserId]);

  const toggleSelectMode = () => {
    if (selectMode) {
      // Clear all selections when exiting select mode
      setSelectedIds([]);
    }
    setSelectMode(!selectMode);
  };

  const toggleSelectItem = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((itemId) => itemId !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const selectAll = () => {
    if (selectedIds.length === filteredSessions.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredSessions.map((session) => session.id));
    }
  };

  const handleDeleteSelected = () => {
    if (selectedIds.length === 0) return;

    deleteSessions(selectedIds);
    setSelectedIds([]);

    if (currentItems.length === selectedIds.length) {
      setCurrentPage(Math.max(1, currentPage - 1));
    }
  };

  // Filter sessions to only show the current user's sessions
  const userSessions = sessions.filter((session) => session.userId === userId);

  const filteredSessions = userSessions.filter((session) =>
    session.title.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const totalPages = Math.ceil(filteredSessions.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentItems = filteredSessions.slice(startIndex, endIndex);

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(totalPages, page)));
  };

  if (loading) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background p-8 text-foreground">
        <div className="flex flex-col items-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
          <p className="text-xl">Loading history...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background p-8 text-foreground">
        <div className="w-full max-w-md rounded-xl border border-destructive bg-card p-6">
          <h2 className="mb-4 text-2xl font-medium text-destructive">Error</h2>
          <p className="text-foreground">{error}</p>
          <Button
            className="mt-4 bg-destructive text-white hover:bg-destructive/80"
            onClick={() => window.location.reload()}
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh w-full bg-background p-4 text-primary md:p-8">
      <div className="mx-auto w-full max-w-7xl">
        <div className="mb-8 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <h1 className="text-3xl font-medium md:text-4xl">Your legal matters</h1>
          <div className="flex items-center gap-4">
            <div className="flex gap-3">
              {selectMode ? (
                <>
                  <Button
                    variant="destructive"
                    onClick={handleDeleteSelected}
                    disabled={selectedIds.length === 0}
                  >
                    <Trash className="mr-2 h-4 w-4" />
                    Delete ({selectedIds.length})
                  </Button>
                  <Button variant="outline" onClick={toggleSelectMode}>
                    Cancel
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      router.push('/cocounsel');

                      // Clear the Zustand store when navigating to home
                      useStore.getState().resetSession();
                    }}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    New legal matter
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-4 top-3 h-5 w-5 text-gray-400" />
          <Input
            placeholder="Search your legal matters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border-border bg-background py-6 pl-12 text-primary focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-400">
            You have {userSessions.length} previous legal matters
            {selectMode && ` (${selectedIds.length} selected)`}
          </p>
          <div className="flex gap-3">
            {selectMode ? (
              <Button variant="default" onClick={selectAll}>
                {selectedIds.length === filteredSessions.length ? 'Deselect all' : 'Select all'}
              </Button>
            ) : (
              <Button variant="default" onClick={toggleSelectMode}>
                Select
              </Button>
            )}
          </div>
        </div>

        <div className="h-[calc(100vh-400px)] overflow-y-auto">
          {currentItems.length === 0 ? (
            <div className="rounded-xl bg-card p-8 text-center">
              <p className="text-lg text-foreground">No legal matters found matching your search</p>
            </div>
          ) : (
            <div className="space-y-3">
              {currentItems.map((session) => (
                <div
                  key={session.id}
                  className={`rounded-lg bg-background p-4 transition-colors duration-200 hover:bg-background/80 ${
                    selectedIds.includes(session.id) ? 'border-2 border-border' : ''
                  }`}
                  onClick={() => (selectMode ? toggleSelectItem(session.id) : null)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {selectMode && (
                        <Checkbox
                          checked={selectedIds.includes(session.id)}
                          onCheckedChange={() => toggleSelectItem(session.id)}
                          className="h-5 w-5 border-border data-[state=checked]:bg-accent-foreground"
                        />
                      )}
                      <Link
                        href={`/analysis/${session.id}`}
                        className="text-lg text-primary hover:underline"
                      >
                        {session.title}
                      </Link>
                    </div>
                    <span className="whitespace-nowrap text-sm text-muted-foreground">
                      Last message {formatTimeAgo(session.updatedAt)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {totalPages > 1 && (
          <div className="mt-8 flex flex-wrap justify-center gap-2">
            <Button variant="outline" onClick={() => goToPage(1)} disabled={currentPage === 1}>
              First
            </Button>
            <Button
              variant="outline"
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              // Show pages around current page
              let pageNum;
              if (totalPages <= 5) {
                pageNum = i + 1;
              } else if (currentPage <= 3) {
                pageNum = i + 1;
              } else if (currentPage >= totalPages - 2) {
                pageNum = totalPages - 4 + i;
              } else {
                pageNum = currentPage - 2 + i;
              }

              return (
                <Button
                  key={pageNum}
                  variant={currentPage === pageNum ? 'default' : 'outline'}
                  onClick={() => goToPage(pageNum)}
                  className={
                    currentPage === pageNum
                      ? 'bg-primary text-primary-foreground hover:bg-primary/80'
                      : 'border-border text-foreground hover:bg-background/50'
                  }
                >
                  {pageNum}
                </Button>
              );
            })}

            <Button
              variant="outline"
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              onClick={() => goToPage(totalPages)}
              disabled={currentPage === totalPages}
            >
              Last
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
