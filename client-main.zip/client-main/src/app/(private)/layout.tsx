import { AppSidebar } from '@/components/app-sidebar';
import AppSidebarProvider from '@/components/app-sidebar-provider';
import { SidebarInset, SidebarTrigger } from '@/components/ui/sidebar';
import React from 'react';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <main className="size-full bg-background">
      <AppSidebarProvider>
        <SidebarTrigger className="fixed left-3 top-2 z-50 hidden max-md:block" />
        <AppSidebar />
        <SidebarInset>{children}</SidebarInset>
      </AppSidebarProvider>
    </main>
  );
}
