'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { useAuth } from '@clerk/nextjs';
import { Loader2 } from 'lucide-react';

import AnalysisPage from './page.client';
import { useStore } from '@/lib/store';

export default function AnalysisPageWrapper() {
  const { id } = useParams();
  const { userId } = useAuth();
  const { fetchAnalysis, setCurrentUserId } = useStore();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      setCurrentUserId(userId);
    }
  }, [userId, setCurrentUserId]);

  useEffect(() => {
    async function loadAnalysis() {
      if (id && userId) {
        setIsLoading(true);
        try {
          await fetchAnalysis(id as string);
        } catch (error) {
          console.error('Error fetching analysis:', error);
        } finally {
          setIsLoading(false);
        }
      }
    }

    loadAnalysis();
  }, [id, userId, fetchAnalysis]);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-lg font-medium text-muted-foreground">Loading analysis...</p>
        </div>
      </div>
    );
  }

  return <AnalysisPage />;
}
