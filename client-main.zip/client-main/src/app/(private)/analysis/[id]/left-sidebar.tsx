'use client';
import { ScrollArea } from '@/components/ui/scroll-area';
import type React from 'react';

import type { MemoSection, RelevantCase } from '@/lib/store';
import { replaceCaseReferencesWithLinks } from '@/lib/utils';
import Markdown from 'markdown-to-jsx';

export default function LeftSidebar({
  memo,
  width,
  selectedTab,
  setSelectedTab,
  relevantCases,
  handleMouseDown,
}: {
  memo: MemoSection;
  width: number;
  selectedTab: 'issues' | 'discussion' | 'conclusion' | null;
  setSelectedTab: (tab: 'issues' | 'discussion' | 'conclusion' | null) => void;
  relevantCases: RelevantCase[];
  handleMouseDown: (e: React.MouseEvent<HTMLDivElement>) => void;
}) {
  return (
    <div
      style={{ width: `${width}px` }}
      className="relative flex-none border-r border-border bg-card"
    >
      <div className="p-6">
        <ScrollArea className="flex h-[calc(90vh-5rem)] flex-col space-y-2">
          <div className="space-y-2">
            <button
              className={`flex w-full items-center justify-between rounded-lg px-4 py-3 text-sm font-medium ${
                selectedTab === 'issues'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
              onClick={() => setSelectedTab(selectedTab === 'issues' ? null : 'issues')}
            >
              Issues
              <span className="text-xs">{selectedTab === 'issues' ? '▼' : '▶'}</span>
            </button>
            {selectedTab === 'issues' && (
              <div className="pl-4 pr-2">
                <Markdown
                  options={{
                    overrides: {
                      a: {
                        props: {
                          className:
                            'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                          target: '_blank',
                          rel: 'noopener noreferrer',
                        },
                      },
                      h1: {
                        props: {
                          className:
                            'text-xl font-bold mt-5 mb-3 text-foreground border-b pb-1 border-border/40',
                        },
                      },
                      h2: {
                        props: {
                          className: 'text-lg font-semibold mt-4 mb-2 text-foreground',
                        },
                      },
                      h3: {
                        props: {
                          className: 'text-base font-medium mt-3 mb-2 text-foreground',
                        },
                      },
                      p: {
                        props: {
                          className: 'text-sm leading-relaxed mb-3 text-foreground',
                        },
                      },
                      ul: {
                        props: {
                          className: 'list-disc pl-4 mb-3 space-y-1.5',
                        },
                      },
                      ol: {
                        props: {
                          className: 'list-decimal pl-4 mb-3 space-y-1.5',
                        },
                      },
                      li: {
                        props: {
                          className: 'text-sm text-foreground',
                        },
                      },
                      blockquote: {
                        props: {
                          className:
                            'border-l-4 border-primary/30 pl-3 py-1 italic my-3 bg-muted/30 rounded-r-sm text-muted-foreground',
                        },
                      },
                      code: {
                        props: {
                          className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                        },
                      },
                      pre: {
                        props: {
                          className:
                            'bg-muted p-3 rounded-md overflow-x-auto my-3 font-mono text-sm',
                        },
                      },
                      table: {
                        props: {
                          className: 'min-w-full divide-y divide-border mb-3 text-sm',
                        },
                      },
                      thead: {
                        props: {
                          className: 'bg-muted/50',
                        },
                      },
                      th: {
                        props: {
                          className:
                            'px-2 py-1.5 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                        },
                      },
                      td: {
                        props: {
                          className: 'px-2 py-1.5 text-sm text-foreground',
                        },
                      },
                    },
                  }}
                >
                  {memo.issues}
                </Markdown>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <button
              className={`flex w-full items-center justify-between rounded-lg px-4 py-3 text-sm font-medium ${
                selectedTab === 'discussion'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
              onClick={() => setSelectedTab(selectedTab === 'discussion' ? null : 'discussion')}
            >
              Discussion
              <span className="text-xs">{selectedTab === 'discussion' ? '▼' : '▶'}</span>
            </button>
            {selectedTab === 'discussion' && (
              <div className="pl-4 pr-2">
                <Markdown
                  options={{
                    overrides: {
                      a: {
                        props: {
                          className:
                            'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                          target: '_blank',
                          rel: 'noopener noreferrer',
                        },
                      },
                      h1: {
                        props: {
                          className:
                            'text-xl font-bold mt-5 mb-3 text-foreground border-b pb-1 border-border/40',
                        },
                      },
                      h2: {
                        props: {
                          className: 'text-lg font-semibold mt-4 mb-2 text-foreground',
                        },
                      },
                      h3: {
                        props: {
                          className: 'text-base font-medium mt-3 mb-2 text-foreground',
                        },
                      },
                      p: {
                        props: {
                          className: 'text-sm leading-relaxed mb-3 text-foreground',
                        },
                      },
                      ul: {
                        props: {
                          className: 'list-disc pl-4 mb-3 space-y-1.5',
                        },
                      },
                      ol: {
                        props: {
                          className: 'list-decimal pl-4 mb-3 space-y-1.5',
                        },
                      },
                      li: {
                        props: {
                          className: 'text-sm text-foreground',
                        },
                      },
                      blockquote: {
                        props: {
                          className:
                            'border-l-4 border-primary/30 pl-3 py-1 italic my-3 bg-muted/30 rounded-r-sm text-muted-foreground',
                        },
                      },
                      code: {
                        props: {
                          className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                        },
                      },
                      pre: {
                        props: {
                          className:
                            'bg-muted p-3 rounded-md overflow-x-auto my-3 font-mono text-sm',
                        },
                      },
                      table: {
                        props: {
                          className: 'min-w-full divide-y divide-border mb-3 text-sm',
                        },
                      },
                      thead: {
                        props: {
                          className: 'bg-muted/50',
                        },
                      },
                      th: {
                        props: {
                          className:
                            'px-2 py-1.5 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                        },
                      },
                      td: {
                        props: {
                          className: 'px-2 py-1.5 text-sm text-foreground',
                        },
                      },
                    },
                  }}
                >
                  {replaceCaseReferencesWithLinks(memo.discussion, relevantCases)}
                </Markdown>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <button
              className={`flex w-full items-center justify-between rounded-lg px-4 py-3 text-sm font-medium ${
                selectedTab === 'conclusion'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}
              onClick={() => setSelectedTab(selectedTab === 'conclusion' ? null : 'conclusion')}
            >
              Conclusion
              <span className="text-xs">{selectedTab === 'conclusion' ? '▼' : '▶'}</span>
            </button>
            {selectedTab === 'conclusion' && (
              <div className="pl-4 pr-2">
                <Markdown
                  options={{
                    overrides: {
                      a: {
                        props: {
                          className:
                            'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                          target: '_blank',
                          rel: 'noopener noreferrer',
                        },
                      },
                      h1: {
                        props: {
                          className:
                            'text-xl font-bold mt-5 mb-3 text-foreground border-b pb-1 border-border/40',
                        },
                      },
                      h2: {
                        props: {
                          className: 'text-lg font-semibold mt-4 mb-2 text-foreground',
                        },
                      },
                      h3: {
                        props: {
                          className: 'text-base font-medium mt-3 mb-2 text-foreground',
                        },
                      },
                      p: {
                        props: {
                          className: 'text-sm leading-relaxed mb-3 text-foreground',
                        },
                      },
                      ul: {
                        props: {
                          className: 'list-disc pl-4 mb-3 space-y-1.5',
                        },
                      },
                      ol: {
                        props: {
                          className: 'list-decimal pl-4 mb-3 space-y-1.5',
                        },
                      },
                      li: {
                        props: {
                          className: 'text-sm text-foreground',
                        },
                      },
                      blockquote: {
                        props: {
                          className:
                            'border-l-4 border-primary/30 pl-3 py-1 italic my-3 bg-muted/30 rounded-r-sm text-muted-foreground',
                        },
                      },
                      code: {
                        props: {
                          className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                        },
                      },
                      pre: {
                        props: {
                          className:
                            'bg-muted p-3 rounded-md overflow-x-auto my-3 font-mono text-sm',
                        },
                      },
                      table: {
                        props: {
                          className: 'min-w-full divide-y divide-border mb-3 text-sm',
                        },
                      },
                      thead: {
                        props: {
                          className: 'bg-muted/50',
                        },
                      },
                      th: {
                        props: {
                          className:
                            'px-2 py-1.5 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                        },
                      },
                      td: {
                        props: {
                          className: 'px-2 py-1.5 text-sm text-foreground',
                        },
                      },
                    },
                  }}
                >
                  {memo.conclusion}
                </Markdown>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Resize handle */}
      <div
        className="absolute right-0 top-0 h-full w-1 cursor-ew-resize transition-colors hover:bg-primary/50"
        onMouseDown={handleMouseDown}
      />
    </div>
  );
}
