'use client';

import type React from 'react';

import { useState, useEffect, useCallback } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Send } from 'lucide-react';
import { useStore } from '@/lib/store';
import { replaceCaseReferencesWithLinks } from '@/lib/utils';
import { useAuth } from '@clerk/nextjs';
import { toast } from '@/hooks/use-toast';
import { marked } from 'marked';
import Markdown from 'markdown-to-jsx';
import { useSidebarStore } from '@/lib/sidebar-store';
import LeftSidebar from './left-sidebar';

export default function AnalysisPage() {
  const router = useRouter();
  const { userId } = useAuth();
  const { currentSession, isProcessing, submitChatMessage, fetchCaseDetails } = useStore();
  const params = useParams();
  const sessionId = params?.id as string;

  const [selectedTab, setSelectedTab] = useState<'issues' | 'discussion' | 'conclusion' | null>(
    'issues',
  );
  const [query, setQuery] = useState('');
  const [isCaseModalOpen, setIsCaseModalOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<any>(null);
  const [caseDetails, setCaseDetails] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [contentTab, setContentTab] = useState<string>('legal-matter');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<number[]>([]);
  const [currentSearchIndex, setCurrentSearchIndex] = useState(0);
  const [caseFileExpanded, setCaseFileExpanded] = useState(true);

  const { width, setWidth } = useSidebarStore();

  useEffect(() => {
    if (sessionId) {
      setIsLoading(true);
      // Optionally, you can fetch the session data here if needed
      setIsLoading(false); // remove this line when implementing fetchSessionData
    }
  }, [sessionId]);

  useEffect(() => {
    // Add click event listener to case citation links
    const handleCitationClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.classList.contains('case-citation-link')) {
        const docId = Number(target.getAttribute('data-docid'));
        const discussionId = Number(target.getAttribute('data-discussionid'));
        const caseTitle = target.textContent || '';

        if (docId && discussionId) {
          handleViewCase({
            docId,
            citation: caseTitle,
            discussionId,
          });
        }
      }
    };

    document.addEventListener('click', handleCitationClick);
    return () => document.removeEventListener('click', handleCitationClick);
  }, []);

  // Search in case file content
  useEffect(() => {
    if (searchTerm && currentSession?.caseFile) {
      setIsSearching(true);

      // Find all occurrences of the search term
      const results: number[] = [];
      const content = currentSession.caseFile.toLowerCase();
      const term = searchTerm.toLowerCase();
      let position = content.indexOf(term);

      while (position !== -1) {
        results.push(position);
        position = content.indexOf(term, position + 1);
      }

      setSearchResults(results);
      setCurrentSearchIndex(results.length > 0 ? 0 : -1);
      setIsSearching(false);

      // Scroll to the first result if found
      if (results.length > 0) {
        scrollToSearchResult(results[0]);
      }
    } else {
      setSearchResults([]);
      setCurrentSearchIndex(-1);
    }
  }, [searchTerm, currentSession?.caseFile]);

  const scrollToSearchResult = (position: number) => {
    const caseFileElement = document.getElementById('case-file-content');
    if (caseFileElement) {
      // Create a temporary marker element
      const marker = document.createElement('span');
      marker.id = 'search-marker';
      marker.style.backgroundColor = 'yellow';

      // Insert the marker at the position
      const content = currentSession?.caseFile || '';
      const beforeMarker = content.substring(0, position);
      const markedText = content.substring(position, position + searchTerm.length);
      const afterMarker = content.substring(position + searchTerm.length);

      caseFileElement.innerHTML = `${beforeMarker}<span class="bg-yellow-300 text-black px-1 rounded">${markedText}</span>${afterMarker}`;

      // Scroll to the marker
      const markerElement = caseFileElement.querySelector('.bg-yellow-300');
      if (markerElement) {
        markerElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  const navigateSearchResults = (direction: 'next' | 'prev') => {
    if (searchResults.length === 0) return;

    let newIndex;
    if (direction === 'next') {
      newIndex = (currentSearchIndex + 1) % searchResults.length;
    } else {
      newIndex = (currentSearchIndex - 1 + searchResults.length) % searchResults.length;
    }

    setCurrentSearchIndex(newIndex);
    scrollToSearchResult(searchResults[newIndex]);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        toast({
          title: 'Copied to clipboard',
          description: 'The content has been copied to your clipboard.',
        });
      })
      .catch((err) => {
        console.error('Failed to copy: ', err);
        toast({
          title: 'Failed to copy',
          description: 'Could not copy the content to clipboard.',
          variant: 'destructive',
        });
      });
  };

  const downloadCaseFile = () => {
    if (!currentSession?.caseFile) return;

    const fileName = currentSession.fileMetadata?.name || 'case-file.txt';
    const blob = new Blob([currentSession.caseFile], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();

      const startX = e.pageX;
      const startWidth = width;

      const handleMouseMove = (e: MouseEvent) => {
        const delta = e.pageX - startX;
        setWidth(startWidth + delta);
      };

      const handleMouseUp = () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [width, setWidth],
  );

  if (!currentSession) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background">
        <div className="mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
        <h2 className="text-xl font-medium">Loading your session...</h2>
      </div>
    );
  }

  // Check if the session belongs to the current user
  if (currentSession.userId !== userId) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-background">
        <div className="mb-4 h-12 w-12 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
        <h2 className="text-xl font-medium">Loading your session...</h2>
      </div>
    );
  }

  const { memo, messages, relevantCases, caseFile, fileMetadata } = currentSession;
  const conversation = messages.filter((m) => m.type !== 'thinking');

  // Extract legal matter from the first user message
  const legalMatter = messages.find((m) => m.role === 'user')?.content || '';

  const initialResearch = relevantCases.map((c) => ({
    docId: c.docId,
    citation: c.caseTitle,
    discussionId: c.discussionId,
    relevance: c.relevance || 'Relevant to the legal problem',
  }));

  const handleFollowUpQuery = async () => {
    if (!query.trim() || isProcessing) return;

    setIsLoading(true);
    await submitChatMessage(query);
    setQuery('');
    setIsLoading(false);
  };

  // Update the handleViewCase function to ensure it works properly with case file content
  const handleViewCase = async (caseItem: any) => {
    setSelectedCase(caseItem);
    setIsLoading(true);

    try {
      const discussionIds = Array.isArray(caseItem.discussionId)
        ? caseItem.discussionId
        : [caseItem.discussionId];

      const details = await fetchCaseDetails(caseItem.docId, discussionIds);

      setCaseDetails({
        summary: formatCaseSummary(details.case_summary),
        text: formatCaseText(details.case_text),
      });

      // Ensure the modal opens after data is loaded
      setTimeout(() => {
        setIsCaseModalOpen(true);
        setIsLoading(false);
      }, 100);
    } catch (error) {
      console.error('Error fetching case details:', error);
      setIsLoading(false);
    }
  };

  // Helper function to process text and replace literal \n with actual newlines
  const processText = (text: string): string => {
    if (!text) return '';
    // Replace literal \n with actual newlines
    return text.replace(/\\n/g, '\n');
  };

  const formatCaseSummary = (summary: any) => {
    if (!summary) return '';

    let formattedSummary = `# ${summary.case_title || 'Case Summary'}\n\n`;

    if (summary.background_facts) {
      formattedSummary += `## Background Facts\n${processText(summary.background_facts)}\n\n`;
    }

    if (summary.legal_issues && summary.legal_issues.length > 0) {
      formattedSummary += `## Legal Issues\n`;
      summary.legal_issues.forEach((issue: any) => {
        formattedSummary += `- ${processText(issue.text)}\n`;
      });
      formattedSummary += '\n';
    }

    if (summary.arguments && summary.arguments.length > 0) {
      // Group arguments by type (appellant/respondent)
      const appellantArgs = summary.arguments.filter((arg: any) => arg.type === 'appellant');
      const respondentArgs = summary.arguments.filter((arg: any) => arg.type === 'respondent');

      // Handle appellant arguments
      if (appellantArgs.length > 0) {
        formattedSummary += `## Appellant Arguments\n\n`;
        appellantArgs.forEach((arg: any) => {
          // Process text and split into paragraphs
          const paragraphs = processText(arg.text).split('\n');
          // First paragraph gets the bullet
          formattedSummary += `- ${paragraphs[0]}\n`;
          // Subsequent paragraphs get proper indentation
          if (paragraphs.length > 1) {
            paragraphs.slice(1).forEach((para) => {
              formattedSummary += `  ${para}\n`;
            });
          }
        });
        formattedSummary += '\n';
      }

      // Handle respondent arguments
      if (respondentArgs.length > 0) {
        formattedSummary += `## Respondent Arguments\n\n`;
        respondentArgs.forEach((arg: any) => {
          // Process text and split into paragraphs
          const paragraphs = processText(arg.text).split('\n');
          // First paragraph gets the bullet
          formattedSummary += `- ${paragraphs[0]}\n`;
          // Subsequent paragraphs get proper indentation
          if (paragraphs.length > 1) {
            paragraphs.slice(1).forEach((para) => {
              formattedSummary += `  ${para}\n`;
            });
          }
        });
        formattedSummary += '\n';
      }
    }

    if (summary.analysis_reasoning && summary.analysis_reasoning.length > 0) {
      formattedSummary += `## Analysis / Reasoning\n`;
      summary.analysis_reasoning.forEach((ar: any) => {
        const highlight = ar.highlight ? '**' : '';
        formattedSummary += `- ${highlight}${processText(ar.text)}${highlight}\n`;
      });
      formattedSummary += '\n';
    }

    if (summary.decision_order) {
      formattedSummary += `## Decision / Order\n${processText(summary.decision_order)}\n\n`;
    }

    if (summary.dissenting_concurring && summary.dissenting_concurring.length > 0) {
      formattedSummary += `## Dissenting / Concurring Opinions\n`;
      summary.dissenting_concurring.forEach((dco: any) => {
        formattedSummary += `- ${processText(dco.text)}\n`;
      });
      formattedSummary += '\n';
    }

    if (summary.cases_referred && summary.cases_referred.length > 0) {
      formattedSummary += `## Cases Referred\n`;
      summary.cases_referred.forEach((c: any) => {
        formattedSummary += `- ${c.case_title || 'Unknown Title'}\n`;
      });
    }

    return formattedSummary;
  };

  const formatCaseText = (text: string) => {
    if (!text) return [];

    // Split by paragraphs and remove HTML tags
    return text
      .split('</p>')
      .map((p) => p.replace(/<\/?[^>]+(>|$)/g, '').trim())
      .filter((p) => p);
  };

  // Extract case file name from metadata or use default
  const caseFileName = fileMetadata?.name || 'Case File';

  return (
    <main className="flex h-screen flex-col bg-background">
      <div className="flex flex-1 overflow-hidden">
        {/* Left sidebar with memo tabs */}
        <LeftSidebar
          memo={memo}
          handleMouseDown={handleMouseDown}
          relevantCases={relevantCases}
          selectedTab={selectedTab}
          setSelectedTab={setSelectedTab}
          width={width}
        />

        {/* Main content area */}
        <div className="flex flex-1 flex-col overflow-hidden bg-muted">
          {/* Case file and legal matter section */}
          {/* <div className="bg-card border-b border-border shadow-sm">
            <div className="max-w-4xl mx-auto">
              <Tabs value={contentTab} onValueChange={setContentTab} className="w-full">
                <div className="flex justify-between items-center px-6 pt-4">
                  <TabsList className="bg-muted/70">
                    <TabsTrigger value="legal-matter" className="text-sm font-medium">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Legal Matter
                    </TabsTrigger>
                    {caseFile && (
                      <TabsTrigger value="case-file" className="text-sm font-medium">
                        <FileText className="h-4 w-4 mr-2" />
                        {caseFileName}
                      </TabsTrigger>
                    )}
                  </TabsList>

                  {contentTab === "case-file" && caseFile && (
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Search in case file..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-8 h-8 w-[200px] text-sm border-muted-foreground/30 focus-visible:ring-primary/50"
                        />
                      </div>
                      {searchResults.length > 0 && (
                        <div className="flex items-center gap-1 text-xs bg-muted/50 px-2 py-1 rounded-md text-muted-foreground">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 hover:bg-muted"
                            onClick={() => navigateSearchResults("prev")}
                            disabled={searchResults.length <= 1}
                          >
                            <ChevronUp className="h-3 w-3" />
                          </Button>
                          <span className="font-medium">
                            {currentSearchIndex + 1}/{searchResults.length}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 hover:bg-muted"
                            onClick={() => navigateSearchResults("next")}
                            disabled={searchResults.length <= 1}
                          >
                            <ChevronDown className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-muted/70 transition-colors"
                        onClick={() => copyToClipboard(caseFile)}
                        title="Copy to clipboard"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-muted/70 transition-colors"
                        onClick={downloadCaseFile}
                        title="Download case file"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-muted/70 transition-colors"
                        onClick={() => setCaseFileExpanded(!caseFileExpanded)}
                        title={caseFileExpanded ? "Collapse" : "Expand"}
                      >
                        {caseFileExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </div>
                  )}
                </div>

                <TabsContent value="legal-matter" className="mt-0 px-6 py-4">
                  <div className="prose prose-sm max-w-none">
                    <div className="text-foreground text-base leading-relaxed whitespace-pre-wrap font-serif bg-card/30 p-4 rounded-md border border-border/30">
                      {legalMatter}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="case-file" className="mt-0">
                  {caseFile && caseFileExpanded ? (
                    <ScrollArea className="h-[300px] px-6 py-4">
                      <div
                        id="case-file-content"
                        className="text-foreground text-base leading-relaxed whitespace-pre-wrap font-serif bg-card/30 p-4 rounded-md border border-border/30"
                      >
                        {caseFile}
                      </div>
                    </ScrollArea>
                  ) : caseFile ? (
                    <div className="px-6 py-4 text-center text-muted-foreground">
                      <Button
                        variant="outline"
                        onClick={() => setCaseFileExpanded(true)}
                        className="flex items-center gap-2 hover:bg-muted/50 transition-colors"
                      >
                        <ChevronDown className="h-4 w-4" />
                        <span>Expand Case File</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="px-6 py-4 text-center text-muted-foreground bg-card/30 mx-6 rounded-md">
                      No case file was uploaded for this session.
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div> */}

          {/* Chat section */}
          <div className="flex-1 overflow-auto">
            <div className="mx-auto max-w-4xl p-8">
              {/* Conversation history */}
              {conversation.length > 0 && (
                <div className="mb-8 space-y-4">
                  {conversation.map((message, index) => (
                    <div
                      key={index}
                      className={`rounded-lg p-4 ${
                        message.role === 'user'
                          ? 'ml-12 bg-card/50 text-foreground'
                          : 'border border-border bg-card text-foreground'
                      }`}
                    >
                      <div className="mb-2 flex items-center">
                        <div
                          className={`h-8 w-8 rounded-full ${
                            message.role === 'user' ? 'bg-accent' : 'bg-primary'
                          } mr-2 flex items-center justify-center`}
                        >
                          {message.role === 'user' ? 'U' : 'AI'}
                        </div>
                        <div className="text-sm font-medium">
                          {message.role === 'user' ? 'You' : 'LeXploR'}
                        </div>
                      </div>

                      <div className="ml-10">
                        {message.role === 'user' ? (
                          <p>{message.content}</p>
                        ) : (
                          <Markdown
                            options={{
                              overrides: {
                                a: {
                                  props: {
                                    className:
                                      'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                                    target: '_blank',
                                    rel: 'noopener noreferrer',
                                  },
                                },
                                h1: {
                                  props: {
                                    className:
                                      'text-2xl font-bold mt-6 mb-4 text-foreground border-b pb-1 border-border/40',
                                  },
                                },
                                h2: {
                                  props: {
                                    className: 'text-xl font-semibold mt-5 mb-3 text-foreground',
                                  },
                                },
                                h3: {
                                  props: {
                                    className: 'text-lg font-medium mt-4 mb-2 text-foreground',
                                  },
                                },
                                p: {
                                  props: {
                                    className: 'text-sm leading-relaxed mb-4 text-foreground',
                                  },
                                },
                                ul: {
                                  props: {
                                    className: 'list-disc pl-5 mb-4 space-y-1.5',
                                  },
                                },
                                ol: {
                                  props: {
                                    className: 'list-decimal pl-5 mb-4 space-y-1.5',
                                  },
                                },
                                li: {
                                  props: {
                                    className: 'text-sm text-foreground',
                                  },
                                },
                                blockquote: {
                                  props: {
                                    className:
                                      'border-l-4 border-primary/30 pl-4 py-1 italic my-4 bg-muted/30 rounded-r-sm text-muted-foreground',
                                  },
                                },
                                code: {
                                  props: {
                                    className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                                  },
                                },
                                pre: {
                                  props: {
                                    className:
                                      'bg-muted p-3 rounded-md overflow-x-auto my-3 font-mono text-sm',
                                  },
                                },
                                table: {
                                  props: {
                                    className: 'min-w-full divide-y divide-border mb-4',
                                  },
                                },
                                thead: {
                                  props: {
                                    className: 'bg-muted/50',
                                  },
                                },
                                th: {
                                  props: {
                                    className:
                                      'px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                                  },
                                },
                                td: {
                                  props: {
                                    className: 'px-3 py-2 text-sm text-foreground',
                                  },
                                },
                              },
                            }}
                          >
                            {replaceCaseReferencesWithLinks(message.content, relevantCases)}
                          </Markdown>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick query input */}
              <div className="sticky bottom-4">
                <div className="rounded-lg border border-border bg-card p-4 shadow-lg">
                  <div className="relative">
                    <Textarea
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder={isProcessing ? 'Thinking' : 'Ask a follow-up question...'}
                      className={`resize-none bg-background pr-12 text-foreground ${
                        isProcessing
                          ? 'thinking-placeholder placeholder-primary'
                          : 'placeholder-muted-foreground'
                      }`}
                      rows={1}
                      disabled={isProcessing}
                    />
                    <Button
                      size="icon"
                      className="absolute right-2 top-1/2 h-8 w-8 -translate-y-1/2 rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
                      onClick={handleFollowUpQuery}
                      disabled={!query.trim() || isProcessing}
                    >
                      {isProcessing ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right sidebar with relevant cases */}
        <div className="w-80 border-l border-border bg-card">
          <div className="p-6">
            <h3 className="mb-4 font-semibold text-foreground">Relevant Cases</h3>
            <ScrollArea className="h-[calc(100vh-10rem)]">
              <div className="space-y-4 pr-4">
                {initialResearch.map((caseItem, index) => (
                  <div
                    key={index}
                    className="group cursor-pointer rounded-lg border border-border/50 bg-muted p-4 shadow-sm transition-colors hover:bg-accent/50 hover:shadow-md"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleViewCase(caseItem);
                    }}
                  >
                    <div className="mb-2 flex flex-col items-start justify-between gap-3">
                      <p className="text-sm font-semibold text-foreground">{caseItem.citation}</p>
                    </div>
                    <div className="max-h-0 overflow-hidden transition-all duration-300 ease-in-out group-hover:max-h-96">
                      <div
                        className="prose prose-sm mt-3 max-w-none rounded-md border border-border/30 bg-background/70 p-3 text-xs text-muted-foreground opacity-0 transition-opacity delay-100 duration-300 group-hover:opacity-100"
                        dangerouslySetInnerHTML={{
                          __html: marked(caseItem.relevance, {
                            gfm: true,
                            breaks: true,
                          }),
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>
      </div>

      {/* Case details modal */}
      <Dialog open={isCaseModalOpen} onOpenChange={setIsCaseModalOpen}>
        <DialogContent className="z-50 max-h-[90vh] max-w-4xl overflow-y-auto p-6">
          <DialogTitle className="text-xl font-semibold text-primary">Case Details</DialogTitle>
          {caseDetails ? (
            <div className="space-y-6">
              <div className="rounded-lg bg-muted/30 p-4">
                <h3 className="mb-2 text-sm font-medium text-foreground">
                  Relevance to Current Matter
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {caseDetails.relevance}
                </p>
              </div>
              <div className="rounded-lg bg-card p-5">
                <h3 className="mb-3 text-base font-semibold text-primary">Case Summary</h3>
                <Markdown
                  options={{
                    overrides: {
                      a: {
                        props: {
                          className:
                            'text-primary hover:text-primary/80 underline underline-offset-2 font-medium transition-colors',
                          target: '_blank',
                          rel: 'noopener noreferrer',
                        },
                      },
                      h1: {
                        props: {
                          className:
                            'text-2xl font-bold mt-6 mb-4 text-foreground border-b pb-1 border-border/40',
                        },
                      },
                      h2: {
                        props: {
                          className: 'text-xl font-semibold mt-5 mb-3 text-foreground',
                        },
                      },
                      h3: {
                        props: {
                          className: 'text-lg font-medium mt-4 mb-2 text-foreground',
                        },
                      },
                      p: {
                        props: {
                          className: 'text-sm leading-relaxed mb-4 text-muted-foreground',
                        },
                      },
                      ul: {
                        props: {
                          className: 'list-disc pl-6 mb-4 space-y-2',
                        },
                      },
                      ol: {
                        props: {
                          className: 'list-decimal pl-6 mb-4 space-y-2',
                        },
                      },
                      li: {
                        props: {
                          className: 'text-sm text-muted-foreground',
                        },
                      },
                      blockquote: {
                        props: {
                          className:
                            'border-l-4 border-primary/30 pl-4 py-2 italic my-4 bg-muted/30 rounded-r-sm text-muted-foreground',
                        },
                      },
                      code: {
                        props: {
                          className: 'bg-muted px-1.5 py-0.5 rounded text-sm font-mono',
                        },
                      },
                      pre: {
                        props: {
                          className:
                            'bg-muted p-3 rounded-md overflow-x-auto my-4 font-mono text-sm',
                        },
                      },
                      table: {
                        props: {
                          className: 'min-w-full divide-y divide-border mb-4',
                        },
                      },
                      thead: {
                        props: {
                          className: 'bg-muted/50',
                        },
                      },
                      th: {
                        props: {
                          className:
                            'px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider',
                        },
                      },
                      td: {
                        props: {
                          className: 'px-3 py-2 text-sm text-muted-foreground',
                        },
                      },
                    },
                  }}
                >
                  {caseDetails.summary}
                </Markdown>
              </div>
              <div className="rounded-lg bg-card p-5">
                <h3 className="mb-3 text-base font-semibold text-primary">Case Text</h3>
                <div className="space-y-3 pr-2 text-justify">
                  {caseDetails.text.map((text: string, index: number) => (
                    <p
                      key={index}
                      className="text-justify text-sm leading-relaxed text-muted-foreground"
                    >
                      {text}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center p-12">
              <div className="h-10 w-10 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
