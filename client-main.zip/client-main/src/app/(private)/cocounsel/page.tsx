import { ChatInterface } from '@/components/chat-interface';

export default function CoCounselPage() {
  return (
    <main className="flex h-screen flex-col bg-background">
      <div className="relative flex-1">
        <ChatInterface />
      </div>
    </main>
  );
}
