// src/middleware.ts
import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';
import { NextResponse } from 'next/server';

// Define public routes that don't require authentication
const isPublicRoute = createRouteMatcher([
  '/sign-in(.*)', // Sign in pages
  '/sign-up(.*)', // Sign up pages
  '/', // Landing page
  '/docs(.*)', // Documentation page
  '/landing(.*)', // Any landing page routes
  '/api(.*)', // API routes
  '/_next(.*)', // Next.js internal routes
  '/favicon.ico', // Favicon
]);

export default clerkMiddleware(async (auth, req) => {
  const { userId } = await auth();
  const { pathname } = new URL(req.url);

  // If the user is authenticated and trying to access sign-in, sign-up, or landing pages
  if (
    userId &&
    (pathname === '/' || pathname.startsWith('/sign-in') || pathname.startsWith('/sign-up'))
  ) {
    // Redirect to cocounsel page
    const cocounselUrl = new URL('/cocounsel', req.url);
    return NextResponse.redirect(cocounselUrl);
  }

  // If the route is public, allow access
  if (isPublicRoute(req)) {
    return NextResponse.next();
  }

  // For protected routes, check authentication
  // If not authenticated, redirect to sign-in
  if (!userId) {
    const signInUrl = new URL('/sign-in', req.url);
    // Preserve the original URL to redirect back after sign-in
    signInUrl.searchParams.set('redirect_url', pathname);
    return NextResponse.redirect(signInUrl);
  }

  // Allow the request to proceed for authenticated users
  return NextResponse.next();
});

// Configure middleware to run on all routes
export const config = {
  matcher: ['/((?!.*\\..*|_next).*)', '/(api|trpc)(.*)'],
};
