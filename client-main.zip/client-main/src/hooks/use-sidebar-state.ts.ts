'use client';

import { useState, useEffect } from 'react';

export function useSidebarState() {
  // Initialize with a default value (we'll update it in useEffect)
  const [isOpen, setIsOpen] = useState<boolean>(true);

  // Load the saved state on component mount
  useEffect(() => {
    // Only run in the browser
    if (typeof window !== 'undefined') {
      const savedState = localStorage.getItem('sidebarState');
      if (savedState !== null) {
        setIsOpen(savedState === 'open');
      }
    }
  }, []);

  // Save state changes to localStorage
  const toggleSidebar = (newState: boolean) => {
    setIsOpen(newState);
    if (typeof window !== 'undefined') {
      localStorage.setItem('sidebarState', newState ? 'open' : 'closed');
    }
  };

  return { isOpen, toggleSidebar };
}
