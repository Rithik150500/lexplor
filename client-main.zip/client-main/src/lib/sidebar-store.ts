import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

interface SidebarState {
  width: number;
  setWidth: (width: number) => void;
  open: boolean;
  setOpen: (open: boolean) => void;
  toggle: () => void;
}

const MIN_WIDTH = 100; // Minimum width in pixels
const DEFAULT_WIDTH = 320; // Default width in pixels

// Create a Zustand store with persistence
export const useSidebarStore = create<SidebarState>()(
  persist(
    (set) => ({
      width: DEFAULT_WIDTH,
      setWidth: (width) => set({ width: Math.max(width, MIN_WIDTH) }), // Enforce minimum width
      open: true, // Default to open
      setOpen: (open) => set({ open }),
      toggle: () => set((state) => ({ open: !state.open })),
    }),
    {
      name: 'sidebar-state', // localStorage key
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
