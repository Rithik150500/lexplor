import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import { extractSections, parseCaseReferences } from './utils';

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  type?: 'thinking' | 'output';
  parts?: string[];
}

export interface CaseReference {
  docId: number;
  caseTitle: string;
  discussionId: number;
}

export interface RelevantCase {
  docId: number;
  caseTitle: string;
  discussionId: number | number[];
  relevance?: string;
}

export interface MemoSection {
  issues: string;
  discussion: string;
  conclusion: string;
}

export interface ChatSession {
  id: string;
  userId: string;
  title: string;
  messages: Message[];
  memo: MemoSection;
  relevantCases: RelevantCase[];
  caseFile?: string;
  fileMetadata?: {
    name: string;
    isBinary: boolean;
  };
  createdAt: Date;
  updatedAt: Date;
}

interface RelevantCaseApiResponse {
  doc_id: number;
  case_title: string;
  discussion_id: number;
  relevance?: string;
}

interface StoreState {
  currentSession: ChatSession | null;
  sessions: ChatSession[];
  isProcessing: boolean;
  partialMemoBuffer: string;
  partialChatBuffer: string;
  currentChatMessageId: string | null;
  chatThinkingMode: boolean;
  currentUserId: string | null;

  // Memo section flags
  discoveredIssuesInvolved: boolean;
  discoveredDiscussionReasoning: boolean;
  discoveredFindingsConclusion: boolean;

  // Actions
  setCurrentUserId: (userId: string) => void;
  createNewSession: () => void;
  setCurrentSession: (sessionId: string) => void;
  updateSessionTitle: (sessionId: string, title: string) => void;
  deleteSession: (sessionId: string) => void;
  deleteSessions: (sessionIds: string[]) => void;
  fetchUserSessions: () => Promise<void>;
  resetSession: () => void;

  // Message actions
  addMessage: (message: Message) => void;
  updateLastMessage: (content: string) => void;

  // Processing actions
  setIsProcessing: (isProcessing: boolean) => void;

  // Memo actions
  updateMemo: (section: keyof MemoSection, content: string) => void;

  // Case actions
  setRelevantCases: (cases: RelevantCase[]) => void;
  updateRelevantCases: (newCaseRefs: CaseReference[]) => void;

  // File actions
  setCaseFile: (content: string, metadata?: { name: string; isBinary: boolean }) => void;

  // SSE handling
  handlePartialMemo: (chunk: string) => void;
  handleDocTitles: (titles: string[]) => void;
  handleRelevantCases: (cases: { case: RelevantCaseApiResponse[] }) => void;
  handlePartialFinalMemo: (chunk: string) => void;
  handleFinalMemo: (memo: string) => void;
  handleConversation: (conversation: any[]) => void;
  handlePartialChatResponse: (chunk: { text: string }) => void;

  // API actions
  submitLegalProblem: (problem: string) => Promise<void>;
  submitChatMessage: (message: string) => Promise<void>;
  fetchCaseDetails: (docId: number, discussionIds: number[]) => Promise<any>;
  fetchAnalysis: (sessionId: string) => Promise<void>;
  saveSession: () => Promise<void>;
}

export const useStore = create<StoreState>()(
  devtools(
    persist(
      (set, get) => ({
        currentSession: null,
        sessions: [],
        isProcessing: false,
        partialMemoBuffer: '',
        partialChatBuffer: '',
        currentChatMessageId: null,
        chatThinkingMode: false,
        currentUserId: null,

        discoveredIssuesInvolved: false,
        discoveredDiscussionReasoning: false,
        discoveredFindingsConclusion: false,

        setCurrentUserId: (userId) => {
          set({ currentUserId: userId });
        },

        createNewSession: () => {
          const userId = get().currentUserId;
          if (!userId) return;

          const newSession: ChatSession = {
            id: crypto.randomUUID(),
            userId,
            title: 'New Legal Research',
            messages: [],
            memo: {
              issues: '',
              discussion: '',
              conclusion: '',
            },
            relevantCases: [],
            createdAt: new Date(),
            updatedAt: new Date(),
          };

          set((state) => ({
            currentSession: newSession,
            sessions: [newSession, ...state.sessions],
            partialMemoBuffer: '',
            partialChatBuffer: '',
            discoveredIssuesInvolved: false,
            discoveredDiscussionReasoning: false,
            discoveredFindingsConclusion: false,
          }));
        },

        setCurrentSession: (sessionId) => {
          const session = get().sessions.find((s) => s.id === sessionId);
          if (session) {
            set({ currentSession: session });
          }
        },

        updateSessionTitle: (sessionId, title) => {
          set((state) => ({
            sessions: state.sessions.map((s) =>
              s.id === sessionId ? { ...s, title, updatedAt: new Date() } : s,
            ),
            currentSession:
              state.currentSession?.id === sessionId
                ? { ...state.currentSession, title, updatedAt: new Date() }
                : state.currentSession,
          }));
        },

        deleteSession: (sessionId) => {
          set((state) => ({
            sessions: state.sessions.filter((s) => s.id !== sessionId),
            currentSession: state.currentSession?.id === sessionId ? null : state.currentSession,
          }));

          // Delete from database
          fetch(`/api/sessions/${sessionId}`, {
            method: 'DELETE',
          }).catch((error) => {
            console.error('Error deleting session:', error);
          });
        },

        deleteSessions: (sessionIds) => {
          set((state) => ({
            sessions: state.sessions.filter((s) => !sessionIds.includes(s.id)),
            currentSession:
              state.currentSession && sessionIds.includes(state.currentSession.id)
                ? null
                : state.currentSession,
          }));

          // Delete from database
          sessionIds.forEach((id) => {
            fetch(`/api/sessions/${id}`, {
              method: 'DELETE',
            }).catch((error) => {
              console.error('Error deleting session:', error);
            });
          });
        },

        fetchUserSessions: async () => {
          const userId = get().currentUserId;
          if (!userId) return;

          try {
            const response = await fetch(`/api/sessions?userId=${userId}`);
            if (response.ok) {
              const sessions = await response.json();
              set({ sessions });
            }
          } catch (error) {
            console.error('Error fetching user sessions:', error);
          }
        },

        addMessage: (message) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession) return state;

            const updatedSession = {
              ...state.currentSession,
              messages: [...state.currentSession.messages, message],
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        updateLastMessage: (content) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession || state.currentSession.messages.length === 0) return state;

            const messages = [...state.currentSession.messages];
            messages[messages.length - 1] = {
              ...messages[messages.length - 1],
              content,
            };

            const updatedSession = {
              ...state.currentSession,
              messages,
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        setIsProcessing: (isProcessing) => {
          set({ isProcessing });
        },

        updateMemo: (section, content) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession) return state;

            const updatedMemo = {
              ...state.currentSession.memo,
              [section]: content,
            };

            const updatedSession = {
              ...state.currentSession,
              memo: updatedMemo,
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        setRelevantCases: (cases) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession) return state;

            const updatedSession = {
              ...state.currentSession,
              relevantCases: cases,
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        updateRelevantCases: (newCaseRefs) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession) return state;

            const currentCases = [...state.currentSession.relevantCases];

            // Add new case references or update existing ones
            newCaseRefs.forEach((newCase) => {
              const existingCaseIndex = currentCases.findIndex((c) => c.docId === newCase.docId);

              if (existingCaseIndex >= 0) {
                // Case exists, update discussion IDs
                const existingCase = currentCases[existingCaseIndex];
                let discussionIds: number[] = [];

                if (typeof existingCase.discussionId === 'number') {
                  discussionIds = [existingCase.discussionId];
                } else if (Array.isArray(existingCase.discussionId)) {
                  discussionIds = [...existingCase.discussionId];
                }

                if (!discussionIds.includes(newCase.discussionId)) {
                  discussionIds.push(newCase.discussionId);
                }

                currentCases[existingCaseIndex] = {
                  ...existingCase,
                  discussionId: discussionIds,
                };
              } else {
                // Add new case
                currentCases.push({
                  docId: newCase.docId,
                  caseTitle: newCase.caseTitle,
                  discussionId: newCase.discussionId,
                });
              }
            });

            const updatedSession = {
              ...state.currentSession,
              relevantCases: currentCases,
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        setCaseFile: (content, metadata) => {
          if (!get().currentSession) return;

          set((state) => {
            if (!state.currentSession) return state;

            const updatedSession = {
              ...state.currentSession,
              caseFile: content,
              fileMetadata: metadata,
              updatedAt: new Date(),
            };

            return {
              currentSession: updatedSession,
              sessions: state.sessions.map((s) =>
                s.id === updatedSession.id ? updatedSession : s,
              ),
            };
          });
        },

        handlePartialMemo: (chunk) => {
          // Display the chunk in the loading indicator
          // This is just for visual feedback, we don't need to store it
        },

        handleDocTitles: (titles) => {
          // Store doc titles for loading animation
          // This is just for visual feedback, we don't need to store it
        },

        handleRelevantCases: (casesData) => {
          const relevantCases = casesData.case.map((c) => ({
            docId: c.doc_id,
            caseTitle: c.case_title,
            discussionId: c.discussion_id,
            relevance: c.relevance,
          }));

          get().setRelevantCases(relevantCases);
        },

        handlePartialFinalMemo: (chunk) => {
          // Accumulate the chunk into the buffer
          const buffer = get().partialMemoBuffer + chunk;
          set({ partialMemoBuffer: buffer });

          // Parse the buffer for memo sections
          const state = get();

          // 1) Issues involved
          if (!state.discoveredIssuesInvolved) {
            const matched = extractSections(buffer, 'issues_involved');
            if (matched) {
              set({
                discoveredIssuesInvolved: true,
                partialMemoBuffer: matched.remaining,
              });
              get().updateMemo('issues', matched.content);
            }
          }

          // 2) Discussion reasoning
          if (!state.discoveredDiscussionReasoning) {
            const matched = extractSections(buffer, 'discussion_reasoning');
            if (matched) {
              set({
                discoveredDiscussionReasoning: true,
                partialMemoBuffer: matched.remaining,
              });
              get().updateMemo('discussion', matched.content);
            }
          }

          // 3) Findings conclusion
          if (!state.discoveredFindingsConclusion) {
            const matched = extractSections(buffer, 'findings_conclusion');
            if (matched) {
              set({
                discoveredFindingsConclusion: true,
                partialMemoBuffer: matched.remaining,
              });
              get().updateMemo('conclusion', matched.content);
            }
          }
        },

        handleFinalMemo: (memo) => {
          // Store the complete memo for reference
          // We've already parsed and stored the sections
        },

        handleConversation: (conversation) => {
          // Update conversation history if needed
        },

        handlePartialChatResponse: (chunk) => {
          // Accumulate the chunk into the buffer
          const buffer = get().partialChatBuffer + chunk.text;
          set({ partialChatBuffer: buffer });

          const state = get();

          // 1) Check for <thinking> start
          const startThinking = buffer.indexOf('<thinking>');
          if (startThinking !== -1) {
            // We found <thinking>, so "thinking" is ON
            const endThinking = buffer.indexOf('</thinking>');

            // If there's no closing </thinking>
            if (endThinking === -1) {
              const content = buffer.substring(startThinking + '<thinking>'.length);

              // If we don't yet have a message for the assistant, create one
              if (!state.currentChatMessageId) {
                get().addMessage({
                  role: 'assistant',
                  content,
                  type: 'thinking',
                });
                set({
                  currentChatMessageId: crypto.randomUUID(),
                  chatThinkingMode: true,
                });
              } else {
                // Otherwise update the existing message
                get().updateLastMessage(content);
              }

              // No removal from buffer here, waiting for the closing </thinking>
              return;
            } else {
              // We have the complete <thinking>...</thinking>
              const content = buffer.substring(startThinking + '<thinking>'.length, endThinking);

              // Display the full thinking text
              if (!state.currentChatMessageId) {
                get().addMessage({
                  role: 'assistant',
                  content,
                  type: 'thinking',
                });
                set({
                  currentChatMessageId: crypto.randomUUID(),
                  chatThinkingMode: true,
                });
              } else {
                get().updateLastMessage(content);
              }

              // Remove the entire <thinking>...</thinking> segment from the buffer
              set({
                partialChatBuffer: buffer.substring(endThinking + '</thinking>'.length),
              });
            }
          }

          // 2) Look for <output> ... </output>
          const startOutput = buffer.indexOf('<output>');
          const endOutput = buffer.indexOf('</output>');

          // If both tags exist, we have a complete <output> block
          if (startOutput !== -1 && endOutput !== -1 && endOutput > startOutput) {
            // Extract final output text
            const rawOutput = buffer.substring(startOutput + '<output>'.length, endOutput);

            // Update the message with the final output
            get().addMessage({
              role: 'assistant',
              content: rawOutput,
              type: 'output',
            });

            // Extract case references from the output
            const caseRefs = parseCaseReferences(rawOutput);
            if (caseRefs.length > 0) {
              get().updateRelevantCases(caseRefs);
            }

            // Reset state for next message
            set({
              partialChatBuffer: buffer.substring(endOutput + '</output>'.length),
              currentChatMessageId: null,
              chatThinkingMode: false,
            });
          }
        },

        submitLegalProblem: async (problem) => {
          const state = get();
          if (state.isProcessing) return;

          // Create a new session if none exists
          if (!state.currentSession) {
            get().createNewSession();
          }

          set({ isProcessing: true });

          try {
            // Add user message
            get().addMessage({
              role: 'user',
              content: problem,
            });

            // Update session title based on the problem
            const sessionId = get().currentSession?.id;
            if (sessionId) {
              const title = problem.length > 50 ? problem.substring(0, 50) + '...' : problem;
              get().updateSessionTitle(sessionId, title);
            }

            // Start SSE connection
            const response = await fetch('/api/process-dispute', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ dispute: problem }),
            });

            if (!response.ok) {
              throw new Error('Failed to process legal problem');
            }

            const reader = response.body?.getReader();
            if (!reader) throw new Error('Failed to get response reader');

            // Process the stream
            const processStream = async () => {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                // Decode the chunk
                const chunk = new TextDecoder().decode(value);

                // Parse SSE events
                const lines = chunk.split('\n');
                let eventName = null;
                let dataBuffer = '';

                for (let i = 0; i < lines.length; i++) {
                  const line = lines[i].trimEnd();

                  if (line.startsWith('event:')) {
                    eventName = line.replace('event:', '').trim();
                  } else if (line.startsWith('data:')) {
                    const data = line.replace('data:', '').trim();
                    dataBuffer += data + '\n';
                  } else if (line === '') {
                    if (eventName && dataBuffer) {
                      // Handle the event
                      await handleSSEEvent(eventName, dataBuffer.trim());
                    }
                    eventName = null;
                    dataBuffer = '';
                  }
                }
              }
            };

            // Handle SSE events
            const handleSSEEvent = async (eventName: string, data: string) => {
              switch (eventName) {
                case 'partial_memo':
                  get().handlePartialMemo(data);
                  break;

                case 'doc_titles':
                  try {
                    const titles = JSON.parse(data);
                    get().handleDocTitles(titles);
                  } catch (e) {
                    console.error('Failed to parse doc_titles', e);
                  }
                  break;

                case 'relevant_cases':
                  try {
                    const cases = JSON.parse(data);
                    get().handleRelevantCases(cases);
                  } catch (e) {
                    console.error('Failed to parse relevant_cases', e);
                  }
                  break;

                case 'partial_final_memo':
                  try {
                    const chunk = JSON.parse(data);
                    get().handlePartialFinalMemo(chunk);
                  } catch (e) {
                    console.error('Failed to parse partial_final_memo', e);
                  }
                  break;

                case 'final_memo':
                  get().handleFinalMemo(data);
                  break;

                case 'conversation':
                  try {
                    const conversation = JSON.parse(data);
                    get().handleConversation(conversation);
                  } catch (e) {
                    console.error('Failed to parse conversation', e);
                  }
                  break;

                case 'done':
                  // Processing complete
                  set({ isProcessing: false });
                  break;

                case 'error':
                  console.error('SSE error:', data);
                  set({ isProcessing: false });
                  break;

                default:
                  console.warn('Unhandled SSE event:', eventName, data);
                  break;
              }
            };

            await processStream();

            // Save the session
            await get().saveSession();
          } catch (error) {
            console.error('Error processing legal problem:', error);
            set({ isProcessing: false });
          }
        },

        submitChatMessage: async (message) => {
          const state = get();
          if (state.isProcessing || !state.currentSession) return;

          set({ isProcessing: true });

          try {
            // Add user message
            get().addMessage({
              role: 'user',
              content: message,
            });

            // Prepare the request data
            const requestData = {
              conversation: state.currentSession.messages.map((m) => ({
                role: m.role,
                parts: [m.content],
              })),
              relevant_cases: {
                case: state.currentSession.relevantCases.map((c) => ({
                  doc_id: c.docId,
                  case_title: c.caseTitle,
                  discussion_id: c.discussionId,
                  relevance: c.relevance,
                })),
              },
              user_task: message,
              dispute: state.currentSession.messages[0]?.content || '',
              final_memo: JSON.stringify(state.currentSession.memo),
            };

            // Save the session before starting the SSE connection
            // This ensures the user message is persisted even if the page is reloaded
            await get().saveSession();

            // Start SSE connection
            const response = await fetch('/api/chat', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(requestData),
            });

            if (!response.ok) {
              throw new Error('Failed to process chat message');
            }

            const reader = response.body?.getReader();
            if (!reader) throw new Error('Failed to get response reader');

            // Process the stream
            const processStream = async () => {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                // Decode the chunk
                const chunk = new TextDecoder().decode(value);

                // Parse SSE events
                const lines = chunk.split('\n');
                let eventName = null;
                let dataBuffer = '';

                for (let i = 0; i < lines.length; i++) {
                  const line = lines[i].trimEnd();

                  if (line.startsWith('event:')) {
                    eventName = line.replace('event:', '').trim();
                  } else if (line.startsWith('data:')) {
                    const data = line.replace('data:', '').trim();
                    dataBuffer += data + '\n';
                  } else if (line === '') {
                    if (eventName && dataBuffer) {
                      // Handle the event
                      await handleSSEEvent(eventName, dataBuffer.trim());
                    }
                    eventName = null;
                    dataBuffer = '';
                  }
                }
              }
            };

            // Handle SSE events
            const handleSSEEvent = async (eventName: string, data: string) => {
              switch (eventName) {
                case 'partial_chat_response':
                  try {
                    const chunk = JSON.parse(data);
                    get().handlePartialChatResponse(chunk);

                    // Save session periodically to persist partial responses
                    if (Math.random() < 0.1) {
                      // Save roughly every 10 chunks
                      await get().saveSession();
                    }
                  } catch (e) {
                    console.error('Failed to parse partial_chat_response', e);
                  }
                  break;

                case 'relevant_cases':
                  try {
                    const cases = JSON.parse(data);
                    get().handleRelevantCases(cases);
                    await get().saveSession(); // Save when cases are updated
                  } catch (e) {
                    console.error('Failed to parse relevant_cases', e);
                  }
                  break;

                case 'conversation':
                  try {
                    const conversation = JSON.parse(data);
                    get().handleConversation(conversation);
                  } catch (e) {
                    console.error('Failed to parse conversation', e);
                  }
                  break;

                case 'done':
                  // Processing complete
                  set({ isProcessing: false });
                  await get().saveSession(); // Save when complete
                  break;

                case 'error':
                  console.error('SSE error:', data);
                  set({ isProcessing: false });
                  break;

                default:
                  console.warn('Unhandled SSE event:', eventName, data);
                  break;
              }
            };

            await processStream();
          } catch (error) {
            console.error('Error processing chat message:', error);
            set({ isProcessing: false });

            // Save session even if there was an error
            await get().saveSession();
          }
        },

        fetchCaseDetails: async (docId, discussionIds) => {
          try {
            const response = await fetch('/api/case-details', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                document_id: docId,
                analysis_reasoning_ids: discussionIds,
              }),
            });

            if (!response.ok) {
              throw new Error('Failed to fetch case details');
            }

            return await response.json();
          } catch (error) {
            console.error('Error fetching case details:', error);
            throw error;
          }
        },

        fetchAnalysis: async (sessionId) => {
          try {
            const session = get().sessions.find((s) => s.id === sessionId);
            if (session) {
              set({ currentSession: session });
            } else {
              // Fetch from database if not in memory
              const response = await fetch(`/api/sessions/${sessionId}`);
              if (response.ok) {
                const session = await response.json();
                set({
                  currentSession: session,
                  sessions: [...get().sessions.filter((s) => s.id !== sessionId), session],
                });
              } else {
                console.error('Failed to fetch session:', await response.text());
              }
            }
          } catch (error) {
            console.error('Error fetching analysis:', error);
          }
        },

        saveSession: async () => {
          const session = get().currentSession;
          if (!session) return;

          try {
            await fetch('/api/sessions', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(session),
            });
          } catch (error) {
            console.error('Error saving session:', error);
          }
        },

        resetSession: () => {
          set({
            currentSession: null,
            partialMemoBuffer: '',
            partialChatBuffer: '',
            currentChatMessageId: null,
            chatThinkingMode: false,
            discoveredIssuesInvolved: false,
            discoveredDiscussionReasoning: false,
            discoveredFindingsConclusion: false,
          });
        },
      }),
      {
        name: 'lexplor-storage',
        partialize: (state) => ({
          sessions: state.sessions,
          currentUserId: state.currentUserId,
        }),
      },
    ),
  ),
);
