import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { CaseReference } from './store';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - new Date(date).getTime()) / 1000);

  if (diffInSeconds < 60) {
    return 'just now';
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
  } else if (diffInSeconds < 2592000) {
    const days = Math.floor(diffInSeconds / 86400);
    return `${days} ${days === 1 ? 'day' : 'days'} ago`;
  } else if (diffInSeconds < 31536000) {
    const months = Math.floor(diffInSeconds / 2592000);
    return `${months} ${months === 1 ? 'month' : 'months'} ago`;
  } else {
    const years = Math.floor(diffInSeconds / 31536000);
    return `${years} ${years === 1 ? 'year' : 'years'} ago`;
  }
}

export function extractSections(buffer: string, sectionName: string) {
  const startTag = `<${sectionName}>`;
  const endTag = `</${sectionName}>`;
  const startIndex = buffer.indexOf(startTag);
  const endIndex = buffer.indexOf(endTag);

  if (startIndex >= 0 && endIndex > startIndex) {
    const innerStart = startIndex + startTag.length;
    const content = buffer.substring(innerStart, endIndex);
    const remaining = buffer.substring(endIndex + endTag.length);
    return { content, remaining };
  }
  return null;
}

export function parseCaseReferences(text: string): CaseReference[] {
  // Regex pattern to match <<doc_id; case_title; discussion_id>>
  const pattern = /<<\s*(\d+)\s*;\s*(.*?)\s*;\s*(\d+)\s*>>/g;
  const matches = Array.from(text.matchAll(pattern));

  return matches.map((match) => ({
    docId: Number.parseInt(match[1]),
    caseTitle: match[2].trim(),
    discussionId: Number.parseInt(match[3]),
  }));
}

export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function replaceCaseReferencesWithLinks(
  text: string,
  relevantCases?: Array<{
    docId: number;
    caseTitle: string;
    discussionId: number | number[];
  }>,
): string {
  if (!text) return '';

  // First, handle the <<doc_id; case_title; discussion_id>> format
  let processedText = text.replace(
    /<<\s*(\d+)\s*;\s*(.*?)\s*;\s*(\d+)\s*>>/g,
    (match, docId, caseTitle, discussionId) => {
      const trimmedTitle = caseTitle.trim();
      return `<span class="case-citation-link" data-docid="${docId}" data-discussionid="${discussionId}" style="font-weight: bold; text-decoration: underline; cursor: pointer;">${trimmedTitle}</span>`;
    },
  );

  // Then, handle known case citations from the relevant cases if provided
  if (relevantCases && relevantCases.length > 0) {
    relevantCases.forEach((caseRef) => {
      if (!caseRef.caseTitle) return;

      // Create a regex that matches the case title, handling potential ellipsis and variations
      const caseTitle = caseRef.caseTitle;
      const escapedTitle = caseTitle
        .replace(/\./g, '\\.')
        .replace(/\(/g, '\\(')
        .replace(/\)/g, '\\)')
        .replace(/\[/g, '\\[')
        .replace(/\]/g, '\\]')
        .replace(/\.\.\./g, '.*?')
        .replace(/\s+vs\s+/i, '\\s+(?:vs|v\\.|versus)\\s+'); // Handle different variations of "vs"

      try {
        const regex = new RegExp(`\\b${escapedTitle}\\b`, 'gi');

        processedText = processedText.replace(regex, (match) => {
          const discussionId = Array.isArray(caseRef.discussionId)
            ? caseRef.discussionId[0]
            : caseRef.discussionId;
          return `<span class="case-citation-link" data-docid="${caseRef.docId}" data-discussionid="${discussionId}" style="font-weight: bold; text-decoration: underline; cursor: pointer;">${match}</span>`;
        });
      } catch (error) {
        console.error(`Error creating regex for case title: ${caseTitle}`, error);
      }
    });
  }

  return processedText;
}
